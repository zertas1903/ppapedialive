/*
  # AI Analizleri Tablosu

  1. Yeni Tablolar
    - `ai_analyses`
      - `id` (uuid, primary key)
      - `title` (text)
      - `category` (text)
      - `description` (text)
      - `analysis_result` (jsonb)
      - `confidence` (integer)
      - `rating` (integer)
      - `status` (text)
      - `user_id` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Güvenlik
    - RLS etkin
    - Kullanıcılar kendi verilerini okuyabilir/yazabilir
*/

CREATE TABLE IF NOT EXISTS ai_analyses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  category text NOT NULL,
  description text,
  analysis_result jsonb,
  confidence integer DEFAULT 0,
  rating integer DEFAULT 0,
  status text DEFAULT 'completed',
  user_id text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE ai_analyses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own analyses"
  ON ai_analyses
  FOR SELECT
  TO authenticated
  USING (auth.uid()::text = user_id);

CREATE POLICY "Users can insert own analyses"
  ON ai_analyses
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid()::text = user_id);

CREATE POLICY "Users can update own analyses"
  ON ai_analyses
  FOR UPDATE
  TO authenticated
  USING (auth.uid()::text = user_id);

-- Örnek veriler ekle
INSERT INTO ai_analyses (title, category, description, analysis_result, confidence, rating, status, user_id) VALUES
(
  'Eksik Baskı Problemi',
  'Plastik Enjeksiyon',
  'Enjeksiyon kalıplama sürecinde malzemenin kalıp boşluğunu tamamen dolduramaması',
  '{
    "problemType": "Plastik Enjeksiyon Hatası",
    "rootCause": "Enjeksiyon basıncının düşük olması, kalıp havalandırmasının yetersizliği",
    "confidence": 89,
    "immediateActions": [
      "Basınç sensörü ile sürekli takip sistemi kurulması",
      "Kalıp havalandırma deliklerinin artırılması",
      "Dolum süresinin optimizasyonu"
    ],
    "recommendations": [
      "Günlük basınç kontrol rutini",
      "Haftalık kalıp temizlik programı",
      "Operatör eğitim programı"
    ]
  }',
  89,
  5,
  'completed',
  'demo-user'
),
(
  'Yanık İzleri',
  'Plastik Enjeksiyon',
  'Kalıp boşluğunda sıkışan havanın yüksek basınç ve sıcaklık altında yanması',
  '{
    "problemType": "Yanık İzleri",
    "rootCause": "Kalıp havalandırma yetersizliği, fazla enjeksiyon hızı",
    "confidence": 92,
    "immediateActions": [
      "Havalandırma sisteminin artırılması",
      "Enjeksiyon hızının optimize edilmesi",
      "Malzeme kurutma prosedürünün uygulanması"
    ],
    "recommendations": [
      "Günlük havalandırma kontrol rutini",
      "Sıcaklık profili takip sistemi",
      "Malzeme nem ölçümü"
    ]
  }',
  92,
  4,
  'completed',
  'demo-user'
),
(
  'Renk Ton Farklılığı',
  'Plastik Enjeksiyon',
  'Pigment dağılımının homojen olmaması nedeniyle farklı renk tonları',
  '{
    "problemType": "Renk Kalitesi Hatası",
    "rootCause": "Masterbatch oranı değişken, pigment homojen karışmamış",
    "confidence": 76,
    "immediateActions": [
      "Masterbatch dozajının kalibre edilmesi",
      "Hammadde kurutma prosedürünün uygulanması",
      "Lot takip sisteminin kurulması"
    ],
    "recommendations": [
      "Günlük renk kontrol rutini",
      "Lot takip sistemi",
      "Dozajlama kalibrasyonu"
    ]
  }',
  76,
  4,
  'in_progress',
  'demo-user'
);
import React, { useState } from 'react';
import { Upload, Download, Brain, FileSpreadsheet, AlertTriangle, CheckCircle, Target, Zap, FileText, BarChart3, Settings, Shield, Eye, Search, BookOpen, Award } from 'lucide-react';

interface UploadedDocument {
  id: string;
  name: string;
  type: 'control-plan' | 'fmea' | 'synoptic' | 'process-flow' | 'other';
  size: string;
  uploadDate: Date;
  status: 'uploaded' | 'analyzing' | 'analyzed';
}

interface AuditFinding {
  id: string;
  category: 'major' | 'minor' | 'observation';
  title: string;
  description: string;
  iatfClause: string;
  recommendation: string;
  priority: 'high' | 'medium' | 'low';
  documentType: string;
}

interface AuditReport {
  overallScore: number;
  totalFindings: number;
  majorFindings: number;
  minorFindings: number;
  observations: number;
  complianceLevel: 'excellent' | 'good' | 'needs-improvement' | 'critical';
  findings: AuditFinding[];
  recommendations: string[];
}

const AIAuditor: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'upload' | 'analyze' | 'report'>('upload');
  const [uploadedDocuments, setUploadedDocuments] = useState<UploadedDocument[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [auditReport, setAuditReport] = useState<AuditReport | null>(null);
  const [analysisComplete, setAnalysisComplete] = useState(false);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      Array.from(files).forEach(file => {
        const newDocument: UploadedDocument = {
          id: `doc-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          name: file.name,
          type: getDocumentType(file.name),
          size: formatFileSize(file.size),
          uploadDate: new Date(),
          status: 'uploaded'
        };
        
        setUploadedDocuments(prev => [...prev, newDocument]);
      });
    }
  };

  const getDocumentType = (fileName: string): UploadedDocument['type'] => {
    const name = fileName.toLowerCase();
    if (name.includes('control') || name.includes('kontrol')) return 'control-plan';
    if (name.includes('fmea')) return 'fmea';
    if (name.includes('synoptic') || name.includes('sinoptik')) return 'synoptic';
    if (name.includes('flow') || name.includes('akış')) return 'process-flow';
    return 'other';
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const getDocumentTypeLabel = (type: UploadedDocument['type']): string => {
    const labels = {
      'control-plan': 'Kontrol Planı',
      'fmea': 'FMEA',
      'synoptic': 'Sinoptik',
      'process-flow': 'Süreç Akışı',
      'other': 'Diğer'
    };
    return labels[type];
  };

  const getDocumentTypeColor = (type: UploadedDocument['type']): string => {
    const colors = {
      'control-plan': 'bg-blue-100 text-blue-800',
      'fmea': 'bg-purple-100 text-purple-800',
      'synoptic': 'bg-green-100 text-green-800',
      'process-flow': 'bg-orange-100 text-orange-800',
      'other': 'bg-gray-100 text-gray-800'
    };
    return colors[type];
  };

  const startAIAudit = () => {
    if (uploadedDocuments.length === 0) {
      alert('Lütfen önce doküman yükleyin!');
      return;
    }

    setIsAnalyzing(true);
    setActiveTab('analyze');
    
    // Update document status to analyzing
    setUploadedDocuments(prev => 
      prev.map(doc => ({ ...doc, status: 'analyzing' }))
    );

    // Simulate AI analysis
    setTimeout(() => {
      // Update document status to analyzed
      setUploadedDocuments(prev => 
        prev.map(doc => ({ ...doc, status: 'analyzed' }))
      );
      
      // Generate mock audit report
      const mockReport = generateMockAuditReport(uploadedDocuments);
      setAuditReport(mockReport);
      setIsAnalyzing(false);
      setAnalysisComplete(true);
      setActiveTab('report');
    }, 5000);
  };

  const generateMockAuditReport = (documents: UploadedDocument[]): AuditReport => {
    const mockFindings: AuditFinding[] = [
      {
        id: 'finding-1',
        category: 'major',
        title: 'Kontrol Planında Risk Değerlendirmesi Eksik',
        description: 'Kontrol planında kritik kontrol noktaları için risk değerlendirmesi yapılmamış. IATF 16949 standardına göre her kontrol noktası için risk analizi gereklidir.',
        iatfClause: '8.5.1.1 - Kontrol Planı',
        recommendation: 'Her kontrol noktası için risk değerlendirmesi yapın ve kontrol planına ekleyin. Risk matrisi kullanarak önceliklendirme yapın.',
        priority: 'high',
        documentType: 'Kontrol Planı'
      },
      {
        id: 'finding-2',
        category: 'minor',
        title: 'FMEA\'da Tespit Değerleri Yüksek',
        description: 'FMEA analizinde tespit değerleri 7\'nin üzerinde olan maddeler mevcut. Bu durum kontrol sisteminin etkinliğini sorgulatmaktadır.',
        iatfClause: '7.1.3.1 - Risk Analizi',
        recommendation: 'Tespit değeri yüksek olan maddeler için ek kontrol yöntemleri geliştirin. Poka-yoke sistemleri değerlendirin.',
        priority: 'medium',
        documentType: 'FMEA'
      },
      {
        id: 'finding-3',
        category: 'observation',
        title: 'Sinoptik Şemada Revizyon Tarihi Eksik',
        description: 'Sinoptik şemada son revizyon tarihi ve onay bilgileri net değil. Doküman kontrolü açısından iyileştirme gerekli.',
        iatfClause: '7.5.3.2 - Doküman Kontrolü',
        recommendation: 'Tüm dokümanlarda revizyon tarihi, versiyon numarası ve onay bilgilerini net şekilde belirtin.',
        priority: 'low',
        documentType: 'Sinoptik'
      },
      {
        id: 'finding-4',
        category: 'major',
        title: 'Müşteri Özel Gereksinimleri Tanımlanmamış',
        description: 'Kontrol planında müşteri özel gereksinimleri (CSR) açık şekilde tanımlanmamış ve işaretlenmemiş.',
        iatfClause: '8.2.3.1 - Müşteri Özel Gereksinimleri',
        recommendation: 'Müşteri özel gereksinimlerini kontrol planında açık şekilde belirtin ve özel sembollerle işaretleyin.',
        priority: 'high',
        documentType: 'Kontrol Planı'
      },
      {
        id: 'finding-5',
        category: 'minor',
        title: 'İstatistiksel Kontrol Yöntemleri Eksik',
        description: 'Kritik karakteristikler için SPC (Statistical Process Control) yöntemleri tanımlanmamış.',
        iatfClause: '9.1.1.1 - İstatistiksel Teknikler',
        recommendation: 'Kritik karakteristikler için uygun SPC yöntemlerini belirleyin ve kontrol planına ekleyin.',
        priority: 'medium',
        documentType: 'Kontrol Planı'
      }
    ];

    const majorCount = mockFindings.filter(f => f.category === 'major').length;
    const minorCount = mockFindings.filter(f => f.category === 'minor').length;
    const observationCount = mockFindings.filter(f => f.category === 'observation').length;
    
    let complianceLevel: AuditReport['complianceLevel'] = 'excellent';
    let overallScore = 85;
    
    if (majorCount > 1) {
      complianceLevel = 'critical';
      overallScore = 45;
    } else if (majorCount === 1) {
      complianceLevel = 'needs-improvement';
      overallScore = 65;
    } else if (minorCount > 2) {
      complianceLevel = 'good';
      overallScore = 75;
    }

    return {
      overallScore,
      totalFindings: mockFindings.length,
      majorFindings: majorCount,
      minorFindings: minorCount,
      observations: observationCount,
      complianceLevel,
      findings: mockFindings,
      recommendations: [
        'Kontrol planlarını IATF 16949 gereksinimlerine göre güncelleyin',
        'Risk değerlendirmesi süreçlerini sistematik hale getirin',
        'Müşteri özel gereksinimlerini net şekilde tanımlayın',
        'İstatistiksel kontrol yöntemlerini geliştirin',
        'Doküman kontrol sistemini iyileştirin'
      ]
    };
  };

  const exportAuditReport = () => {
    if (!auditReport) return;

    let csvContent = "IATF 16949 AI Denetim Raporu\n\n";
    csvContent += `Genel Puan,${auditReport.overallScore}\n`;
    csvContent += `Uygunluk Seviyesi,${auditReport.complianceLevel}\n`;
    csvContent += `Toplam Bulgu,${auditReport.totalFindings}\n`;
    csvContent += `Major Bulgu,${auditReport.majorFindings}\n`;
    csvContent += `Minor Bulgu,${auditReport.minorFindings}\n`;
    csvContent += `Gözlem,${auditReport.observations}\n\n`;
    
    csvContent += "Bulgular\n";
    csvContent += "Kategori,Başlık,Açıklama,IATF Maddesi,Öneri,Öncelik,Doküman Tipi\n";
    
    auditReport.findings.forEach(finding => {
      csvContent += `"${finding.category}","${finding.title}","${finding.description}","${finding.iatfClause}","${finding.recommendation}","${finding.priority}","${finding.documentType}"\n`;
    });

    csvContent += "\nGenel Öneriler\n";
    auditReport.recommendations.forEach((rec, index) => {
      csvContent += `${index + 1},"${rec}"\n`;
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `IATF_AI_Denetim_Raporu_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getCategoryColor = (category: string) => {
    const colorMap: Record<string, string> = {
      major: 'bg-red-100 text-red-800 border-red-200',
      minor: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      observation: 'bg-blue-100 text-blue-800 border-blue-200'
    };
    return colorMap[category] || colorMap.observation;
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'major':
        return <AlertTriangle className="w-4 h-4" />;
      case 'minor':
        return <Target className="w-4 h-4" />;
      case 'observation':
        return <Eye className="w-4 h-4" />;
      default:
        return <Eye className="w-4 h-4" />;
    }
  };

  const getComplianceLevelColor = (level: string) => {
    const colorMap: Record<string, string> = {
      excellent: 'bg-green-100 text-green-800',
      good: 'bg-blue-100 text-blue-800',
      'needs-improvement': 'bg-yellow-100 text-yellow-800',
      critical: 'bg-red-100 text-red-800'
    };
    return colorMap[level] || colorMap.good;
  };

  const getComplianceLevelLabel = (level: string) => {
    const labels: Record<string, string> = {
      excellent: 'Mükemmel',
      good: 'İyi',
      'needs-improvement': 'İyileştirme Gerekli',
      critical: 'Kritik'
    };
    return labels[level] || 'İyi';
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">AI Denetçi</h2>
        <p className="text-gray-600 mt-1">IATF 16949 uygunluk denetimi ve analizi</p>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="flex border-b border-gray-200">
          <button
            onClick={() => setActiveTab('upload')}
            className={`flex-1 px-6 py-4 text-center font-medium transition-colors duration-200 ${
              activeTab === 'upload'
                ? 'bg-amber-50 text-amber-600 border-b-2 border-amber-500'
                : 'text-gray-600 hover:text-amber-600 hover:bg-amber-50'
            }`}
          >
            <Upload className="w-5 h-5 mx-auto mb-1" />
            Doküman Yükle
          </button>
          <button
            onClick={() => setActiveTab('analyze')}
            className={`flex-1 px-6 py-4 text-center font-medium transition-colors duration-200 ${
              activeTab === 'analyze'
                ? 'bg-amber-50 text-amber-600 border-b-2 border-amber-500'
                : 'text-gray-600 hover:text-amber-600 hover:bg-amber-50'
            }`}
          >
            <Brain className="w-5 h-5 mx-auto mb-1" />
            AI Denetimi
          </button>
          <button
            onClick={() => setActiveTab('report')}
            className={`flex-1 px-6 py-4 text-center font-medium transition-colors duration-200 ${
              activeTab === 'report'
                ? 'bg-amber-50 text-amber-600 border-b-2 border-amber-500'
                : 'text-gray-600 hover:text-amber-600 hover:bg-amber-50'
            }`}
          >
            <BarChart3 className="w-5 h-5 mx-auto mb-1" />
            Denetim Raporu
          </button>
        </div>

        <div className="p-6">
          {activeTab === 'upload' && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="bg-amber-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Upload className="w-8 h-8 text-amber-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Kalite Dokümanlarını Yükleyin</h3>
                <p className="text-gray-600 mb-6">
                  Kontrol Plan, FMEA, Sinoptik ve diğer kalite dokümanlarınızı yükleyin
                </p>
              </div>

              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-amber-400 transition-colors duration-200">
                <input
                  type="file"
                  accept=".pdf,.xlsx,.xls,.docx,.doc,.pptx,.ppt"
                  onChange={handleFileUpload}
                  multiple
                  className="hidden"
                  id="document-upload"
                />
                <label
                  htmlFor="document-upload"
                  className="cursor-pointer flex flex-col items-center"
                >
                  <FileText className="w-12 h-12 text-gray-400 mb-4" />
                  <span className="text-lg font-medium text-gray-700 mb-2">
                    Dosyaları seçmek için tıklayın
                  </span>
                  <span className="text-sm text-gray-500">
                    veya dosyaları buraya sürükleyin (Çoklu seçim desteklenir)
                  </span>
                </label>
              </div>

              {uploadedDocuments.length > 0 && (
                <div className="space-y-4">
                  <h4 className="text-lg font-semibold text-gray-900">Yüklenen Dokümanlar</h4>
                  <div className="grid grid-cols-1 gap-4">
                    {uploadedDocuments.map((doc) => (
                      <div key={doc.id} className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <FileText className="w-8 h-8 text-gray-400" />
                            <div>
                              <h5 className="font-medium text-gray-900">{doc.name}</h5>
                              <div className="flex items-center space-x-2 text-sm text-gray-600">
                                <span>{doc.size}</span>
                                <span>•</span>
                                <span>{doc.uploadDate.toLocaleDateString('tr-TR')}</span>
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center space-x-3">
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${getDocumentTypeColor(doc.type)}`}>
                              {getDocumentTypeLabel(doc.type)}
                            </span>
                            
                            <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                              doc.status === 'uploaded' ? 'bg-blue-100 text-blue-800' :
                              doc.status === 'analyzing' ? 'bg-yellow-100 text-yellow-800' :
                              'bg-green-100 text-green-800'
                            }`}>
                              {doc.status === 'uploaded' ? 'Yüklendi' :
                               doc.status === 'analyzing' ? 'Analiz Ediliyor' : 'Analiz Edildi'}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="flex justify-center">
                    <button
                      onClick={startAIAudit}
                      className="flex items-center px-8 py-3 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors duration-200"
                    >
                      <Shield className="w-5 h-5 mr-2" />
                      AI Denetimi Başlat
                    </button>
                  </div>
                </div>
              )}

              <div className="bg-amber-50 border border-amber-200 rounded-lg p-6">
                <h4 className="text-lg font-semibold text-amber-900 mb-4">Desteklenen Doküman Türleri</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-amber-800">
                  <div>
                    <p><strong>Kalite Dokümanları:</strong></p>
                    <ul className="list-disc list-inside space-y-1 ml-4">
                      <li>Kontrol Planı (Control Plan)</li>
                      <li>FMEA (Failure Mode and Effects Analysis)</li>
                      <li>Sinoptik Şema</li>
                      <li>Süreç Akış Şemaları</li>
                      <li>İş Talimatları</li>
                    </ul>
                  </div>
                  <div>
                    <p><strong>Dosya Formatları:</strong></p>
                    <ul className="list-disc list-inside space-y-1 ml-4">
                      <li>PDF (.pdf)</li>
                      <li>Excel (.xlsx, .xls)</li>
                      <li>Word (.docx, .doc)</li>
                      <li>PowerPoint (.pptx, .ppt)</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'analyze' && (
            <div className="space-y-6">
              {isAnalyzing ? (
                <div className="text-center py-12">
                  <div className="bg-amber-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <Brain className="w-8 h-8 text-amber-600 animate-pulse" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">AI Denetimi Devam Ediyor</h3>
                  <p className="text-gray-600 mb-6">
                    Dokümanlarınız IATF 16949 standartlarına göre analiz ediliyor...
                  </p>
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-amber-600 mx-auto mb-4"></div>
                  
                  <div className="max-w-md mx-auto">
                    <div className="space-y-2 text-sm text-gray-600">
                      <p>✓ Doküman yapısı analiz ediliyor</p>
                      <p>✓ IATF 16949 uygunluğu kontrol ediliyor</p>
                      <p>✓ Risk değerlendirmeleri inceleniyor</p>
                      <p>✓ Müşteri gereksinimleri kontrol ediliyor</p>
                      <p>⏳ Denetim raporu hazırlanıyor...</p>
                    </div>
                  </div>
                </div>
              ) : uploadedDocuments.length > 0 ? (
                <div className="text-center py-12">
                  <div className="bg-green-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Denetim Tamamlandı</h3>
                  <p className="text-gray-600 mb-6">
                    {uploadedDocuments.length} doküman başarıyla analiz edildi
                  </p>
                  <button
                    onClick={() => setActiveTab('report')}
                    className="flex items-center px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200 mx-auto"
                  >
                    <BarChart3 className="w-5 h-5 mr-2" />
                    Denetim Raporunu Görüntüle
                  </button>
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="bg-gray-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <Brain className="w-8 h-8 text-gray-400" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Denetim Bekliyor</h3>
                  <p className="text-gray-600">Önce dokümanlarınızı yükleyin ve denetimi başlatın</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'report' && auditReport && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">IATF 16949 Denetim Raporu</h3>
                  <p className="text-gray-600">AI tarafından oluşturulan uygunluk değerlendirmesi</p>
                </div>
                <button
                  onClick={exportAuditReport}
                  className="flex items-center px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Raporu İndir
                </button>
              </div>

              {/* Overall Score */}
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-gray-900 mb-2">{auditReport.overallScore}</div>
                    <div className="text-sm text-gray-600">Genel Puan</div>
                  </div>
                  <div className="text-center">
                    <div className={`inline-flex items-center px-4 py-2 rounded-full text-sm font-medium ${getComplianceLevelColor(auditReport.complianceLevel)}`}>
                      {getComplianceLevelLabel(auditReport.complianceLevel)}
                    </div>
                    <div className="text-sm text-gray-600 mt-2">Uygunluk Seviyesi</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-red-600 mb-2">{auditReport.majorFindings}</div>
                    <div className="text-sm text-gray-600">Major Bulgu</div>
                  </div>
                  <div className="text-center">
                    <div className="text-3xl font-bold text-yellow-600 mb-2">{auditReport.minorFindings}</div>
                    <div className="text-sm text-gray-600">Minor Bulgu</div>
                  </div>
                </div>
              </div>

              {/* Findings */}
              <div className="bg-white border border-gray-200 rounded-lg">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h4 className="text-lg font-semibold text-gray-900">Denetim Bulguları</h4>
                </div>
                <div className="p-6">
                  <div className="space-y-6">
                    {auditReport.findings.map((finding) => (
                      <div key={finding.id} className="border border-gray-200 rounded-lg p-6">
                        <div className="flex items-start justify-between mb-4">
                          <div className="flex-1">
                            <div className="flex items-center mb-2">
                              <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${getCategoryColor(finding.category)}`}>
                                {getCategoryIcon(finding.category)}
                                <span className="ml-1 capitalize">{finding.category}</span>
                              </div>
                              <span className="ml-3 text-sm text-gray-600">{finding.documentType}</span>
                            </div>
                            <h5 className="text-lg font-semibold text-gray-900 mb-2">{finding.title}</h5>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          <div>
                            <h6 className="font-medium text-gray-900 mb-2 flex items-center">
                              <Search className="w-4 h-4 mr-2 text-blue-600" />
                              Bulgu Açıklaması
                            </h6>
                            <p className="text-sm text-gray-700 bg-blue-50 p-3 rounded-lg">
                              {finding.description}
                            </p>
                          </div>

                          <div>
                            <h6 className="font-medium text-gray-900 mb-2 flex items-center">
                              <BookOpen className="w-4 h-4 mr-2 text-purple-600" />
                              IATF 16949 Maddesi
                            </h6>
                            <p className="text-sm text-gray-700 bg-purple-50 p-3 rounded-lg">
                              {finding.iatfClause}
                            </p>
                          </div>

                          <div className="md:col-span-2">
                            <h6 className="font-medium text-gray-900 mb-2 flex items-center">
                              <Target className="w-4 h-4 mr-2 text-green-600" />
                              Düzeltici Eylem Önerisi
                            </h6>
                            <p className="text-sm text-gray-700 bg-green-50 p-3 rounded-lg">
                              {finding.recommendation}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Recommendations */}
              <div className="bg-white border border-gray-200 rounded-lg">
                <div className="px-6 py-4 border-b border-gray-200">
                  <h4 className="text-lg font-semibold text-gray-900 flex items-center">
                    <Award className="w-5 h-5 mr-2 text-amber-600" />
                    Genel İyileştirme Önerileri
                  </h4>
                </div>
                <div className="p-6">
                  <div className="space-y-3">
                    {auditReport.recommendations.map((recommendation, index) => (
                      <div key={index} className="flex items-start space-x-3 bg-amber-50 p-4 rounded-lg">
                        <div className="bg-amber-200 text-amber-800 rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold flex-shrink-0">
                          {index + 1}
                        </div>
                        <p className="text-sm text-amber-800">{recommendation}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'report' && !auditReport && (
            <div className="text-center py-12">
              <div className="bg-gray-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <BarChart3 className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Rapor Hazır Değil</h3>
              <p className="text-gray-600">Önce dokümanlarınızı yükleyin ve AI denetimini tamamlayın</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AIAuditor;
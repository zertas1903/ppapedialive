import React from 'react';
import { Brain, CheckSquare, Sparkles, Zap, Target, Users, TrendingUp, Shield, MessageCircle, FileText, Upload, FileSpreadsheet, AlertTriangle } from 'lucide-react';
import FeedbackSystem from './FeedbackSystem';
import PowerBIDashboard from './PowerBIDashboard';

interface LandingPageProps {
  onModeSelect: (mode: '8d' | 'work' | 'calculations' | 'reverse-fmea') => void;
}

const LandingPage: React.FC<LandingPageProps> = ({ onModeSelect }) => {
  const [showFeedback, setShowFeedback] = React.useState(false);
  const [showPowerBI, setShowPowerBI] = React.useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-72 h-72 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute top-40 right-20 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-40 w-72 h-72 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-4000"></div>
      </div>

      {/* Header */}
      <header className="relative z-10 pt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className="mr-4">
                <img 
                  src="/ppapedia-logo.png"
                  alt="PPAPedia Logo" 
                  className="h-12 w-12 object-contain"
                />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">PPAPedia</h1>
                <p className="text-blue-200">AI Powered Quality Engineering Platform</p>
              </div>
            </div>
            
            <div className="flex items-center bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-2 rounded-full text-sm">
              <Sparkles className="w-4 h-4 mr-2" />
              AI Destekli Platform
            </div>
            <p className="text-blue-400 text-xs mt-1 opacity-75">
              Created by Zafer Ertaş
            </p>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-8">
            <img 
              src="/ppapedia-logo.png"
              alt="PPAPedia Logo" 
              className="h-20 w-20 mr-6 object-contain"
            />
            <h2 className="text-5xl md:text-6xl font-bold text-white leading-tight">
              <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">PPAPedia</span>
            </h2>
          </div>
          <h3 className="text-3xl md:text-4xl font-bold text-white mb-6 leading-tight">
            Hangi Modda Çalışmak İstiyorsunuz?
          </h3>
          <p className="text-xl text-blue-200 mb-8 max-w-3xl mx-auto">
            PPAP süreçlerinizi optimize edin, kalite problemlerinizi AI ile çözün ve iş takibinizi modernize edin
          </p>
        </div>

        {/* Mode Selection Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6 mb-16">
          {/* AI Auditor Mode - First */}
          <div 
            onClick={() => onModeSelect('ai-auditor')}
            className="group relative bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300 cursor-pointer transform hover:scale-105 hover:shadow-2xl"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-amber-500/20 to-orange-500/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            
            <div className="relative z-10">
              <div className="flex items-center mb-4">
                <div className="bg-gradient-to-r from-amber-500 to-orange-500 p-3 rounded-xl mr-3">
                  <Shield className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">AI Denetçi</h3>
                  <p className="text-amber-200 text-sm">IATF Uygunluk Denetimi</p>
                </div>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex items-center text-white">
                  <Upload className="w-4 h-4 mr-2 text-amber-400" />
                  <span className="text-sm">Kontrol Plan & FMEA yükleme</span>
                </div>
                <div className="flex items-center text-white">
                  <Brain className="w-4 h-4 mr-2 text-amber-400" />
                  <span className="text-sm">IATF denetmeni gibi analiz</span>
                </div>
                <div className="flex items-center text-white">
                  <AlertTriangle className="w-4 h-4 mr-2 text-amber-400" />
                  <span className="text-sm">Uygunsuzluk tespiti</span>
                </div>
                <div className="flex items-center text-white">
                  <Target className="w-4 h-4 mr-2 text-amber-400" />
                  <span className="text-sm">İyileştirme önerileri</span>
                </div>
              </div>

              <div className="bg-gradient-to-r from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg font-semibold text-center group-hover:shadow-lg transition-shadow duration-300 text-sm">
                AI Denetimi Başlat
              </div>
            </div>
          </div>

          {/* Work Tracker Mode - Second */}
          <div 
            onClick={() => onModeSelect('work')}
            className="group relative bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300 cursor-pointer transform hover:scale-105 hover:shadow-2xl"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-cyan-500/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            
            <div className="relative z-10">
              <div className="flex items-center mb-4">
                <div className="bg-gradient-to-r from-blue-500 to-cyan-500 p-3 rounded-xl mr-3">
                  <CheckSquare className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">İş Takip Sistemi</h3>
                  <p className="text-blue-200 text-sm">Akıllı Proje Yönetimi</p>
                </div>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex items-center text-white">
                  <Target className="w-4 h-4 mr-2 text-blue-400" />
                  <span className="text-sm">Görev ve proje takibi</span>
                </div>
                <div className="flex items-center text-white">
                  <Users className="w-4 h-4 mr-2 text-blue-400" />
                  <span className="text-sm">Ekip yoğunluğu analizi</span>
                </div>
                <div className="flex items-center text-white">
                  <TrendingUp className="w-4 h-4 mr-2 text-blue-400" />
                  <span className="text-sm">Performans dashboard'u</span>
                </div>
                <div className="flex items-center text-white">
                  <Zap className="w-4 h-4 mr-2 text-blue-400" />
                  <span className="text-sm">Otomatik raporlama</span>
                </div>
              </div>

              <div className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-4 py-2 rounded-lg font-semibold text-center group-hover:shadow-lg transition-shadow duration-300 text-sm">
                İş Takibine Başla
              </div>
            </div>
          </div>

          {/* 8D Assistant Mode - Third */}
          <div 
            onClick={() => onModeSelect('8d')}
            className="group relative bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300 cursor-pointer transform hover:scale-105 hover:shadow-2xl"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            
            <div className="relative z-10">
              <div className="flex items-center mb-4">
                <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-3 rounded-xl mr-3">
                  <Brain className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">PPAP & 8D Analizi</h3>
                  <p className="text-purple-200 text-sm">AI Destekli Kalite Mühendisliği</p>
                </div>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex items-center text-white">
                  <Target className="w-4 h-4 mr-2 text-purple-400" />
                  <span className="text-sm">PPAP süreç optimizasyonu</span>
                </div>
                <div className="flex items-center text-white">
                  <Brain className="w-4 h-4 mr-2 text-purple-400" />
                  <span className="text-sm">AI destekli problem analizi</span>
                </div>
                <div className="flex items-center text-white">
                  <Shield className="w-4 h-4 mr-2 text-purple-400" />
                  <span className="text-sm">8D metodolojisi & kök neden</span>
                </div>
                <div className="flex items-center text-white">
                  <TrendingUp className="w-4 h-4 mr-2 text-purple-400" />
                  <span className="text-sm">Kalite metrikleri takibi</span>
                </div>
              </div>

              <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-2 rounded-lg font-semibold text-center group-hover:shadow-lg transition-shadow duration-300 text-sm">
                PPAP & 8D Analizine Başla
              </div>
            </div>
          </div>

          {/* Reverse FMEA Mode - Fourth */}
          <div 
            onClick={() => onModeSelect('reverse-fmea')}
            className="group relative bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300 cursor-pointer transform hover:scale-105 hover:shadow-2xl"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/20 to-purple-500/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            
            <div className="relative z-10">
              <div className="flex items-center mb-4">
                <div className="bg-gradient-to-r from-indigo-500 to-purple-500 p-3 rounded-xl mr-3">
                  <FileText className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Reverse FMEA</h3>
                  <p className="text-indigo-200 text-sm">AI Destekli Önleyici Eylem Planı</p>
                </div>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex items-center text-white">
                  <Upload className="w-4 h-4 mr-2 text-indigo-400" />
                  <span className="text-sm">FMEA dosyası yükleme</span>
                </div>
                <div className="flex items-center text-white">
                  <Brain className="w-4 h-4 mr-2 text-indigo-400" />
                  <span className="text-sm">AI ile analiz ve değerlendirme</span>
                </div>
                <div className="flex items-center text-white">
                  <Target className="w-4 h-4 mr-2 text-indigo-400" />
                  <span className="text-sm">Önleyici eylem planı oluşturma</span>
                </div>
                <div className="flex items-center text-white">
                  <FileSpreadsheet className="w-4 h-4 mr-2 text-indigo-400" />
                  <span className="text-sm">Excel formatında export</span>
                </div>
              </div>

              <div className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white px-4 py-2 rounded-lg font-semibold text-center group-hover:shadow-lg transition-shadow duration-300 text-sm">
                Reverse FMEA Oluştur
              </div>
            </div>
          </div>

          {/* Calculations Mode - Fifth */}
          <div 
            onClick={() => onModeSelect('calculations')}
            className="group relative bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300 cursor-pointer transform hover:scale-105 hover:shadow-2xl"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-green-500/20 to-teal-500/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            
            <div className="relative z-10">
              <div className="flex items-center mb-4">
                <div className="bg-gradient-to-r from-green-500 to-teal-500 p-3 rounded-xl mr-3">
                  <TrendingUp className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Kalite Hesaplamaları</h3>
                  <p className="text-green-200 text-sm">Cp/Cpk & İstatistiksel Analiz</p>
                </div>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex items-center text-white">
                  <TrendingUp className="w-4 h-4 mr-2 text-green-400" />
                  <span className="text-sm">Proses yeterlilik (Cp/Cpk)</span>
                </div>
                <div className="flex items-center text-white">
                  <TrendingUp className="w-4 h-4 mr-2 text-green-400" />
                  <span className="text-sm">Power BI entegrasyonu</span>
                </div>
                <div className="flex items-center text-white">
                  <Zap className="w-4 h-4 mr-2 text-green-400" />
                  <span className="text-sm">Excel/CSV export</span>
                </div>
              </div>

              <div className="bg-gradient-to-r from-green-500 to-teal-500 text-white px-4 py-2 rounded-lg font-semibold text-center group-hover:shadow-lg transition-shadow duration-300 text-sm">
                Hesaplamalara Başla
              </div>
            </div>
          </div>
        </div>

        {/* Power BI Dashboard - Separate Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 mb-16">
          <div className="xl:col-start-2">
          <div 
            onClick={() => setShowPowerBI(!showPowerBI)}
            className="group relative bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 hover:bg-white/20 transition-all duration-300 cursor-pointer transform hover:scale-105 hover:shadow-2xl"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-orange-500/20 to-red-500/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            
            <div className="relative z-10">
              <div className="flex items-center mb-4">
                <div className="bg-gradient-to-r from-orange-500 to-red-500 p-3 rounded-xl mr-3">
                  <TrendingUp className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Power BI Dashboard</h3>
                  <p className="text-orange-200 text-sm">Canlı Raporlar & Analitik</p>
                </div>
              </div>

              <div className="space-y-3 mb-6">
                <div className="flex items-center text-white">
                  <TrendingUp className="w-4 h-4 mr-2 text-orange-400" />
                  <span className="text-sm">Canlı dashboard görüntüleme</span>
                </div>
                <div className="flex items-center text-white">
                  <Target className="w-4 h-4 mr-2 text-orange-400" />
                  <span className="text-sm">Interaktif raporlar</span>
                </div>
                <div className="flex items-center text-white">
                  <Brain className="w-4 h-4 mr-2 text-orange-400" />
                  <span className="text-sm">Gerçek zamanlı veriler</span>
                </div>
                <div className="flex items-center text-white">
                  <Zap className="w-4 h-4 mr-2 text-orange-400" />
                  <span className="text-sm">Kolay entegrasyon</span>
                </div>
              </div>

              <div className={`text-white px-6 py-3 rounded-lg font-semibold text-center group-hover:shadow-lg transition-all duration-300 ${
                showPowerBI 
                  ? 'bg-gradient-to-r from-red-600 to-orange-600' 
                  : 'bg-gradient-to-r from-orange-500 to-red-500'
              } text-sm`}>
                {showPowerBI ? 'Dashboard\'u Gizle' : 'Power BI Dashboard\'a Başla'}
              </div>
            </div>
          </div>
        </div>
        </div>

        {/* Power BI Dashboard Section */}
        {showPowerBI && (
          <div className="mb-16">
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
              <PowerBIDashboard />
            </div>
          </div>
        )}

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
            <div className="bg-gradient-to-r from-green-400 to-blue-500 p-3 rounded-lg w-fit mb-4">
              <Zap className="h-6 w-6 text-white" />
            </div>
            <h4 className="text-lg font-semibold text-white mb-2">Hızlı & Akıllı</h4>
            <p className="text-blue-200 text-sm">AI teknolojisi ile saniyeler içinde analiz ve öneriler</p>
          </div>

          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
            <div className="bg-gradient-to-r from-purple-400 to-pink-500 p-3 rounded-lg w-fit mb-4">
              <Shield className="h-6 w-6 text-white" />
            </div>
            <h4 className="text-lg font-semibold text-white mb-2">Güvenli & Güvenilir</h4>
            <p className="text-blue-200 text-sm">Endüstri standardı güvenlik ve veri koruması</p>
          </div>

          <div className="bg-white/5 backdrop-blur-sm rounded-xl p-6 border border-white/10">
            <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-3 rounded-lg w-fit mb-4">
              <TrendingUp className="h-6 w-6 text-white" />
            </div>
            <h4 className="text-lg font-semibold text-white mb-2">Sürekli Gelişim</h4>
            <p className="text-blue-200 text-sm">Kullanım verilerinizden öğrenen adaptif sistem</p>
          </div>
        </div>

      </div>

      {/* Footer */}
      <footer className="relative z-10 text-center py-8">
        <p className="text-blue-300 text-sm">
          © 2025 PPAPedia - AI Powered Quality Engineering Platform. Tüm hakları saklıdır.
        </p>
        <p className="text-blue-400 text-xs mt-2 opacity-75">
          Created by Zafer Ertaş
        </p>
      </footer>

      {/* Feedback Button */}
      <button
        onClick={() => setShowFeedback(true)}
        className="fixed bottom-6 right-6 w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center z-50 hover:scale-110"
        title="Beni Geliştir"
      >
        <MessageCircle className="w-6 h-6" />
      </button>

      {/* Feedback System Modal */}
      {showFeedback && (
        <FeedbackSystem onClose={() => setShowFeedback(false)} />
      )}
    </div>
  );
};

export default LandingPage;
import React, { useState } from 'react';
import { Send, Brain, FileText, Star } from 'lucide-react';
import ProgressSteps from './ProgressSteps';
import AIAnalysisPanel from './AIAnalysisPanel';
import { getRelevantProblems, generateTechnicalAnalysis } from '../data/problemDatabase';
import { useAIAnalyses } from '../hooks/useAIAnalyses';

interface ProblemData {
  title: string;
  description: string;
  category: string;
  severity: string;
  department: string;
  discoveryDate: string;
  customerImpact: string;
}

const ProblemForm: React.FC = () => {
  const { addAnalysis } = useAIAnalyses();
  const [formData, setFormData] = useState<ProblemData>({
    title: '',
    description: '',
    category: '',
    severity: '',
    department: '',
    discoveryDate: '',
    customerImpact: ''
  });

  const [currentStep, setCurrentStep] = useState(1);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [showRating, setShowRating] = useState(false);
  const [userRating, setUserRating] = useState(0);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateStep = (step: number): boolean => {
    switch (step) {
      case 1:
        return formData.title.trim() !== '' && formData.description.trim() !== '';
      case 2:
        return formData.category !== '' && formData.severity !== '';
      case 3:
        return formData.department !== '' && formData.discoveryDate !== '';
      default:
        return true;
    }
  };

  const nextStep = () => {
    if (currentStep < 4 && validateStep(currentStep)) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const analyzeWithAI = async () => {
    setIsAnalyzing(true);
    
    // Gerçek mühendislik veritabanından analiz
    const relevantProblems = getRelevantProblems(formData.description, formData.category);
    
    setTimeout(async () => {
      const technicalAnalysis = generateTechnicalAnalysis(formData, relevantProblems);
      
      setAnalysisResult(technicalAnalysis);
      setIsAnalyzing(false);
      setShowRating(true);
      
      // Analizi veritabanına kaydet
      try {
        await addAnalysis({
          title: formData.title,
          category: formData.category,
          description: formData.description,
          analysis_result: technicalAnalysis,
          confidence: technicalAnalysis.confidence,
          rating: 0,
          status: 'completed',
          user_id: 'current-user' // Gerçek uygulamada auth.user.id kullanılacak
        });
        console.log('Analiz veritabanına kaydedildi');
      } catch (error) {
        console.error('Analiz kaydedilirken hata:', error);
        // Hata durumunda kullanıcıya bilgi verilebilir
      }
    }, 2000);
  };

  const submitRating = (rating: number) => {
    setUserRating(rating);
    setShowRating(false);
    
    // Rating'i veritabanında güncelle
    if (analysisResult) {
      // Gerçek uygulamada analysis ID'si ile güncelleme yapılacak
      console.log('User rating:', rating);
    }
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div>
              <label htmlFor="title" className="block text-sm font-semibold text-gray-700 mb-2">
                Problem Başlığı *
              </label>
              <input
                type="text"
                id="title"
                name="title"
                value={formData.title}
                onChange={handleInputChange}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                placeholder="Problemi kısaca özetleyin"
              />
            </div>
            
            <div>
              <label htmlFor="description" className="block text-sm font-semibold text-gray-700 mb-2">
                Detaylı Problem Açıklaması *
              </label>
              <textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                rows={6}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 resize-none"
                placeholder="Problemin detaylarını, ne zaman başladığını, hangi koşullarda ortaya çıktığını açıklayın..."
              />
            </div>
            
            <div>
              <label htmlFor="customerImpact" className="block text-sm font-semibold text-gray-700 mb-2">
                Müşteri Etkisi
              </label>
              <textarea
                id="customerImpact"
                name="customerImpact"
                value={formData.customerImpact}
                onChange={handleInputChange}
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 resize-none"
                placeholder="Bu problemin müşteri üzerindeki etkilerini açıklayın..."
              />
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="category" className="block text-sm font-semibold text-gray-700 mb-2">
                  Problem Kategorisi *
                </label>
                <select
                  id="category"
                  name="category"
                  value={formData.category}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                >
                  <option value="">Kategori seçin</option>
                  <option value="quality">Kalite Hatası</option>
                  <option value="process">Süreç Hatası</option>
                  <option value="material">Malzeme Hatası</option>
                  <option value="equipment">Ekipman Hatası</option>
                  <option value="human">İnsan Hatası</option>
                  <option value="environment">Çevre Hatası</option>
                </select>
              </div>

              <div>
                <label htmlFor="severity" className="block text-sm font-semibold text-gray-700 mb-2">
                  Önem Derecesi *
                </label>
                <select
                  id="severity"
                  name="severity"
                  value={formData.severity}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                >
                  <option value="">Önem derecesi seçin</option>
                  <option value="critical">Kritik</option>
                  <option value="high">Yüksek</option>
                  <option value="medium">Orta</option>
                  <option value="low">Düşük</option>
                </select>
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="department" className="block text-sm font-semibold text-gray-700 mb-2">
                  Sorumlu Departman *
                </label>
                <select
                  id="department"
                  name="department"
                  value={formData.department}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                >
                  <option value="">Departman seçin</option>
                  <option value="production">Üretim</option>
                  <option value="quality">Kalite</option>
                  <option value="maintenance">Bakım</option>
                  <option value="engineering">Mühendislik</option>
                  <option value="procurement">Satın Alma</option>
                  <option value="logistics">Lojistik</option>
                </select>
              </div>

              <div>
                <label htmlFor="discoveryDate" className="block text-sm font-semibold text-gray-700 mb-2">
                  Keşif Tarihi *
                </label>
                <input
                  type="date"
                  id="discoveryDate"
                  name="discoveryDate"
                  value={formData.discoveryDate}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                />
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center py-8">
              <div className="bg-green-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Brain className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">AI Analizi Hazır</h3>
              <p className="text-gray-600 mb-6">
                Girdiğiniz bilgiler doğrultusunda AI destekli 8D analizi başlatabilirsiniz.
              </p>
              
              <button
                onClick={analyzeWithAI}
                disabled={isAnalyzing}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-3 rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center mx-auto"
              >
                {isAnalyzing ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Analiz Ediliyor...
                  </>
                ) : (
                  <>
                    <Brain className="w-5 h-5 mr-2" />
                    8D Analizi Başlat
                  </>
                )}
              </button>
            </div>

            {analysisResult && (
              <>
                <AIAnalysisPanel analysis={analysisResult} />
                
                {showRating && (
                  <div className="mt-8 p-6 bg-yellow-50 rounded-lg border border-yellow-200">
                    <h4 className="text-lg font-semibold text-gray-900 mb-4">Bu Analizi Değerlendirin</h4>
                    <p className="text-gray-600 mb-4">
                      AI analizinin kalitesi hakkında geri bildiriminiz önemli. Bu analizin ne kadar yararlı olduğunu değerlendirin:
                    </p>
                    <div className="flex items-center space-x-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          onClick={() => submitRating(star)}
                          className={`p-1 rounded transition-colors duration-200 ${
                            star <= userRating ? 'text-yellow-500' : 'text-gray-300 hover:text-yellow-400'
                          }`}
                        >
                          <Star className="w-6 h-6 fill-current" />
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {userRating > 0 && !showRating && (
                  <div className="mt-4 p-4 bg-green-50 rounded-lg border border-green-200">
                    <p className="text-green-800">
                      Teşekkürler! {userRating} yıldız verdiniz. Geri bildiriminiz sistemin öğrenmesine yardımcı oluyor.
                    </p>
                  </div>
                )}
              </>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
      <div className="lg:col-span-1">
        <ProgressSteps currentStep={currentStep} />
      </div>
      
      <div className="lg:col-span-3">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">
              Problem Bilgilerini Girin
            </h2>
            <p className="text-gray-600 mt-1">
              8D analizi için gerekli bilgileri adım adım doldurun
            </p>
          </div>
          
          <div className="p-6">
            {renderStep()}
            
            {currentStep < 4 && (
              <div className="flex justify-between mt-8">
                <button
                  onClick={prevStep}
                  disabled={currentStep === 1}
                  className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Önceki
                </button>
                
                <button
                  onClick={nextStep}
                  disabled={!validateStep(currentStep)}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center"
                >
                  Sonraki
                  <Send className="w-4 h-4 ml-2" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProblemForm;
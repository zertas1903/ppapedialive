import React, { useState, useEffect } from 'react'
import { Wifi, WifiOff, AlertCircle, Users, Clock } from 'lucide-react'
import { supabase, checkConnection } from '../lib/supabase'

export const RealTimeIndicator: React.FC = () => {
  const [isConnected, setIsConnected] = useState<boolean | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [onlineUsers, setOnlineUsers] = useState<number>(0)
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date())

  useEffect(() => {
    const checkConnectionStatus = async () => {
      try {
        const result = await checkConnection();
        setIsConnected(result.connected);
        setError(result.error?.message || null);
        setLastUpdate(new Date());
      } catch (err) {
        // Handle placeholder credentials gracefully
        if (err instanceof Error && err.message.includes('placeholder')) {
          setIsConnected(false);
          setError('Supabase yapılandırması gerekli');
        } else {
          setIsConnected(false);
          setError('Bağlantı hatası');
        }
        setLastUpdate(new Date());
      }
    };

    checkConnectionStatus()
    const interval = setInterval(checkConnectionStatus, 10000) // Her 10 saniyede kontrol

    // Online kullanıcı sayısını simüle et (gerçek uygulamada presence kullanılır)
    const userInterval = setInterval(() => {
      setOnlineUsers(Math.floor(Math.random() * 8) + 3) // 3-10 arası
    }, 15000)

    return () => {
      clearInterval(interval)
      clearInterval(userInterval)
    }
  }, [])

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <div className="bg-white rounded-lg shadow-lg border border-gray-200 p-4 min-w-[200px]">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center">
            {isConnected ? (
              <Wifi className="w-4 h-4 text-green-500 mr-2" />
            ) : (
              <WifiOff className="w-4 h-4 text-red-500 mr-2" />
            )}
            <span className={`text-sm font-medium ${
              isConnected ? 'text-green-700' : 'text-red-700'
            }`}>
              {isConnected ? 'Bağlı' : 'Bağlantı Yok'}
            </span>
          </div>
          
          <div className="flex items-center text-blue-600">
            <Users className="w-4 h-4 mr-1" />
            <span className="text-sm font-medium">{onlineUsers}</span>
          </div>
        </div>
        
        <div className="flex items-center text-xs text-gray-500">
          <Clock className="w-3 h-3 mr-1" />
          <span>Son güncelleme: {lastUpdate.toLocaleTimeString('tr-TR')}</span>
        </div>
        
        {isConnected && (
          <div className="mt-2 flex items-center">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-2"></div>
            <span className="text-xs text-green-600">Anlık güncellemeler aktif</span>
          </div>
        )}
      </div>
    </div>
  )
}

export default RealTimeIndicator
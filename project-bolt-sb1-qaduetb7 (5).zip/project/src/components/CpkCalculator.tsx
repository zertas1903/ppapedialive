import React, { useState, useEffect } from 'react';
import { Calculator, Download, Shuffle, Copy, TrendingUp, Target, AlertTriangle, CheckCircle, BarChart3, FileSpreadsheet } from 'lucide-react';

interface MeasurementData {
  nominal: number;
  upperTolerance: number;
  lowerTolerance: number;
  measurements: number[];
  inputMode: 'manual' | 'automatic';
}

interface StatisticalResults {
  mean: number;
  standardDeviation: number;
  cp: number;
  cpk: number;
  cpkUpper: number;
  cpkLower: number;
  processCapability: string;
  recommendation: string;
}

const CpkCalculator: React.FC = () => {
  const [data, setData] = useState<MeasurementData>({
    nominal: 100,
    upperTolerance: 0.5,
    lowerTolerance: 0.5,
    measurements: Array(30).fill(''),
    inputMode: 'manual'
  });

  const [results, setResults] = useState<StatisticalResults | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);

  const handleInputChange = (field: keyof MeasurementData, value: any) => {
    setData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleMeasurementChange = (index: number, value: string) => {
    const newMeasurements = [...data.measurements];
    newMeasurements[index] = value === '' ? '' : parseFloat(value) || '';
    setData(prev => ({
      ...prev,
      measurements: newMeasurements
    }));
  };

  const generateAutomaticMeasurements = () => {
    const { nominal, upperTolerance, lowerTolerance } = data;
    const upperLimit = nominal + upperTolerance;
    const lowerLimit = nominal - lowerTolerance;
    
    // Normal dağılım simülasyonu için Box-Muller transform
    const generateNormalRandom = (mean: number, stdDev: number) => {
      let u = 0, v = 0;
      while(u === 0) u = Math.random(); // Converting [0,1) to (0,1)
      while(v === 0) v = Math.random();
      const z = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
      return z * stdDev + mean;
    };

    // Proses standart sapmasını toleransın 1/6'sı olarak ayarla (6 sigma yaklaşımı)
    const processStdDev = (upperTolerance + lowerTolerance) / 12;
    
    const automaticMeasurements = Array(30).fill(0).map(() => {
      let measurement = generateNormalRandom(nominal, processStdDev);
      // Bazen spec dışı değerler de olabilir (gerçekçi olması için)
      if (Math.random() < 0.05) { // %5 ihtimalle spec dışı
        measurement = Math.random() < 0.5 ? 
          lowerLimit - Math.random() * 0.1 : 
          upperLimit + Math.random() * 0.1;
      }
      return parseFloat(measurement.toFixed(3));
    });

    setData(prev => ({
      ...prev,
      measurements: automaticMeasurements
    }));
  };

  const calculateStatistics = async () => {
    setIsCalculating(true);
    
    // Sadece sayısal değerleri al
    const validMeasurements = data.measurements.filter(m => m !== '' && !isNaN(Number(m))).map(Number);
    
    if (validMeasurements.length < 5) {
      alert('En az 5 ölçüm değeri gereklidir!');
      setIsCalculating(false);
      return;
    }

    // İstatistiksel hesaplamalar
    const mean = validMeasurements.reduce((sum, val) => sum + val, 0) / validMeasurements.length;
    
    const variance = validMeasurements.reduce((sum, val) => sum + Math.pow(val - mean, 2), 0) / (validMeasurements.length - 1);
    const standardDeviation = Math.sqrt(variance);
    
    const upperSpecLimit = data.nominal + data.upperTolerance;
    const lowerSpecLimit = data.nominal - data.lowerTolerance;
    const specRange = upperSpecLimit - lowerSpecLimit;
    
    // Cp hesaplama
    const cp = specRange / (6 * standardDeviation);
    
    // Cpk hesaplama
    const cpkUpper = (upperSpecLimit - mean) / (3 * standardDeviation);
    const cpkLower = (mean - lowerSpecLimit) / (3 * standardDeviation);
    const cpk = Math.min(cpkUpper, cpkLower);
    
    // Proses yeterlilik değerlendirmesi
    let processCapability = '';
    let recommendation = '';
    
    if (cpk >= 1.67) {
      processCapability = 'Mükemmel';
      recommendation = 'Proses çok iyi kontrol altında. Mevcut durumu koruyun.';
    } else if (cpk >= 1.33) {
      processCapability = 'Yeterli';
      recommendation = 'Proses kabul edilebilir seviyede. Sürekli iyileştirme yapın.';
    } else if (cpk >= 1.0) {
      processCapability = 'Marjinal';
      recommendation = 'Proses kritik seviyede. Acil iyileştirme gerekli.';
    } else {
      processCapability = 'Yetersiz';
      recommendation = 'Proses kabul edilemez. Derhal düzeltici eylem alın.';
    }

    setTimeout(() => {
      setResults({
        mean: parseFloat(mean.toFixed(4)),
        standardDeviation: parseFloat(standardDeviation.toFixed(4)),
        cp: parseFloat(cp.toFixed(4)),
        cpk: parseFloat(cpk.toFixed(4)),
        cpkUpper: parseFloat(cpkUpper.toFixed(4)),
        cpkLower: parseFloat(cpkLower.toFixed(4)),
        processCapability,
        recommendation
      });
      setIsCalculating(false);
    }, 1500);
  };

  const exportToExcel = () => {
    const validMeasurements = data.measurements.filter(m => m !== '' && !isNaN(Number(m)));
    
    let csvContent = "Cp/Cpk Analiz Raporu\n\n";
    csvContent += "Parametre,Değer\n";
    csvContent += `Nominal Ölçü,${data.nominal}\n`;
    csvContent += `Üst Tolerans,+${data.upperTolerance}\n`;
    csvContent += `Alt Tolerans,-${data.lowerTolerance}\n`;
    csvContent += `Üst Spec Limiti,${data.nominal + data.upperTolerance}\n`;
    csvContent += `Alt Spec Limiti,${data.nominal - data.lowerTolerance}\n\n`;
    
    if (results) {
      csvContent += "İstatistiksel Sonuçlar,\n";
      csvContent += `Ortalama,${results.mean}\n`;
      csvContent += `Standart Sapma,${results.standardDeviation}\n`;
      csvContent += `Cp,${results.cp}\n`;
      csvContent += `Cpk,${results.cpk}\n`;
      csvContent += `Cpk Üst,${results.cpkUpper}\n`;
      csvContent += `Cpk Alt,${results.cpkLower}\n`;
      csvContent += `Proses Yeterlilik,${results.processCapability}\n\n`;
    }
    
    csvContent += "Ölçüm Sonuçları\n";
    csvContent += "Sıra,Değer\n";
    validMeasurements.forEach((measurement, index) => {
      csvContent += `${index + 1},${measurement}\n`;
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `Cpk_Analizi_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const copyToClipboard = () => {
    const validMeasurements = data.measurements.filter(m => m !== '' && !isNaN(Number(m)));
    const textToCopy = validMeasurements.join('\t');
    navigator.clipboard.writeText(textToCopy);
    alert('Ölçüm değerleri panoya kopyalandı!');
  };

  const getCapabilityColor = (cpk: number) => {
    if (cpk >= 1.67) return 'text-green-600 bg-green-100';
    if (cpk >= 1.33) return 'text-blue-600 bg-blue-100';
    if (cpk >= 1.0) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getCapabilityIcon = (cpk: number) => {
    if (cpk >= 1.33) return <CheckCircle className="w-5 h-5" />;
    if (cpk >= 1.0) return <AlertTriangle className="w-5 h-5" />;
    return <AlertTriangle className="w-5 h-5" />;
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Cp/Cpk Hesaplama</h2>
        <p className="text-gray-600 mt-1">Proses yeterlilik analizi ve istatistiksel kontrol</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Input Panel */}
        <div className="lg:col-span-2 space-y-6">
          {/* Specification Inputs */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <Target className="w-5 h-5 mr-2 text-blue-600" />
              Spesifikasyon Bilgileri
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nominal Ölçü
                </label>
                <input
                  type="number"
                  step="0.001"
                  value={data.nominal}
                  onChange={(e) => handleInputChange('nominal', parseFloat(e.target.value) || 0)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Üst Tolerans (+)
                </label>
                <input
                  type="number"
                  step="0.001"
                  value={data.upperTolerance}
                  onChange={(e) => handleInputChange('upperTolerance', parseFloat(e.target.value) || 0)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Alt Tolerans (-)
                </label>
                <input
                  type="number"
                  step="0.001"
                  value={data.lowerTolerance}
                  onChange={(e) => handleInputChange('lowerTolerance', parseFloat(e.target.value) || 0)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-sm text-blue-800">
                <strong>Spec Limitleri:</strong> Alt: {(data.nominal - data.lowerTolerance).toFixed(3)} | 
                Üst: {(data.nominal + data.upperTolerance).toFixed(3)} | 
                Tolerans Aralığı: {(data.upperTolerance + data.lowerTolerance).toFixed(3)}
              </p>
            </div>
          </div>

          {/* Measurement Input Mode */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 flex items-center">
                <BarChart3 className="w-5 h-5 mr-2 text-green-600" />
                Ölçüm Sonuçları
              </h3>
              
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => handleInputChange('inputMode', 'manual')}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
                      data.inputMode === 'manual'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    Manuel
                  </button>
                  <button
                    onClick={() => handleInputChange('inputMode', 'automatic')}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
                      data.inputMode === 'automatic'
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    Otomatik
                  </button>
                </div>
                
                {data.inputMode === 'automatic' && (
                  <button
                    onClick={generateAutomaticMeasurements}
                    className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
                  >
                    <Shuffle className="w-4 h-4 mr-2" />
                    Üret
                  </button>
                )}
              </div>
            </div>

            <div className="grid grid-cols-5 md:grid-cols-6 lg:grid-cols-10 gap-2">
              {data.measurements.map((measurement, index) => (
                <div key={index} className="relative">
                  <label className="block text-xs text-gray-500 mb-1">#{index + 1}</label>
                  <input
                    type="number"
                    step="0.001"
                    value={measurement}
                    onChange={(e) => handleMeasurementChange(index, e.target.value)}
                    disabled={data.inputMode === 'automatic'}
                    className="w-full px-2 py-2 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent disabled:bg-gray-50"
                    placeholder="0.000"
                  />
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between mt-4">
              <p className="text-sm text-gray-600">
                Girilen değer sayısı: {data.measurements.filter(m => m !== '' && !isNaN(Number(m))).length}/30
              </p>
              
              <div className="flex items-center space-x-2">
                <button
                  onClick={copyToClipboard}
                  className="flex items-center px-3 py-2 text-sm bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors duration-200"
                >
                  <Copy className="w-4 h-4 mr-1" />
                  Kopyala
                </button>
                
                <button
                  onClick={calculateStatistics}
                  disabled={isCalculating || data.measurements.filter(m => m !== '' && !isNaN(Number(m))).length < 5}
                  className="flex items-center px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isCalculating ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Hesaplanıyor...
                    </>
                  ) : (
                    <>
                      <Calculator className="w-4 h-4 mr-2" />
                      Hesapla
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Results Panel */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 sticky top-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
              <TrendingUp className="w-5 h-5 mr-2 text-purple-600" />
              Analiz Sonuçları
            </h3>

            {results ? (
              <div className="space-y-4">
                {/* Capability Status */}
                <div className={`p-4 rounded-lg border ${getCapabilityColor(results.cpk)}`}>
                  <div className="flex items-center mb-2">
                    {getCapabilityIcon(results.cpk)}
                    <span className="ml-2 font-semibold">{results.processCapability}</span>
                  </div>
                  <p className="text-sm">{results.recommendation}</p>
                </div>

                {/* Statistical Values */}
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-700">Ortalama (x̄)</span>
                    <span className="font-semibold text-gray-900">{results.mean}</span>
                  </div>
                  
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-700">Std. Sapma (σ)</span>
                    <span className="font-semibold text-gray-900">{results.standardDeviation}</span>
                  </div>
                  
                  <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <span className="text-sm font-medium text-blue-700">Cp</span>
                    <span className="font-bold text-blue-900">{results.cp}</span>
                  </div>
                  
                  <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg border border-purple-200">
                    <span className="text-sm font-medium text-purple-700">Cpk</span>
                    <span className="font-bold text-purple-900">{results.cpk}</span>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <div className="flex justify-between items-center p-2 bg-gray-50 rounded text-xs">
                      <span className="text-gray-600">Cpk Üst</span>
                      <span className="font-medium">{results.cpkUpper}</span>
                    </div>
                    <div className="flex justify-between items-center p-2 bg-gray-50 rounded text-xs">
                      <span className="text-gray-600">Cpk Alt</span>
                      <span className="font-medium">{results.cpkLower}</span>
                    </div>
                  </div>
                </div>

                {/* Export Button */}
                <button
                  onClick={exportToExcel}
                  className="w-full flex items-center justify-center px-4 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
                >
                  <FileSpreadsheet className="w-4 h-4 mr-2" />
                  Excel'e Aktar
                </button>
              </div>
            ) : (
              <div className="text-center py-8">
                <Calculator className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500 text-sm">
                  Hesaplama yapmak için en az 5 ölçüm değeri girin ve "Hesapla" butonuna tıklayın.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Information Panel */}
      <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200 p-6">
        <h4 className="text-lg font-semibold text-gray-900 mb-4">Cp/Cpk Değerlendirme Kriterleri</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white rounded-lg p-4 border border-green-200">
            <div className="flex items-center mb-2">
              <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
              <span className="font-semibold text-green-800">Mükemmel</span>
            </div>
            <p className="text-sm text-gray-600">Cpk ≥ 1.67</p>
            <p className="text-xs text-gray-500 mt-1">Dünya klasmanı proses</p>
          </div>
          
          <div className="bg-white rounded-lg p-4 border border-blue-200">
            <div className="flex items-center mb-2">
              <CheckCircle className="w-5 h-5 text-blue-600 mr-2" />
              <span className="font-semibold text-blue-800">Yeterli</span>
            </div>
            <p className="text-sm text-gray-600">1.33 ≤ Cpk &lt; 1.67</p>
            <p className="text-xs text-gray-500 mt-1">Kabul edilebilir proses</p>
          </div>
          
          <div className="bg-white rounded-lg p-4 border border-yellow-200">
            <div className="flex items-center mb-2">
              <AlertTriangle className="w-5 h-5 text-yellow-600 mr-2" />
              <span className="font-semibold text-yellow-800">Marjinal</span>
            </div>
            <p className="text-sm text-gray-600">1.0 ≤ Cpk &lt; 1.33</p>
            <p className="text-xs text-gray-500 mt-1">İyileştirme gerekli</p>
          </div>
          
          <div className="bg-white rounded-lg p-4 border border-red-200">
            <div className="flex items-center mb-2">
              <AlertTriangle className="w-5 h-5 text-red-600 mr-2" />
              <span className="font-semibold text-red-800">Yetersiz</span>
            </div>
            <p className="text-sm text-gray-600">Cpk &lt; 1.0</p>
            <p className="text-xs text-gray-500 mt-1">Acil eylem gerekli</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CpkCalculator;
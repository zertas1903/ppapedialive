import React from 'react';
import { Check, FileText, AlertTriangle, Calendar, Brain } from 'lucide-react';

interface ProgressStepsProps {
  currentStep: number;
}

const ProgressSteps: React.FC<ProgressStepsProps> = ({ currentStep }) => {
  const steps = [
    { 
      id: 1, 
      title: 'Problem Tanımı', 
      description: 'Problem detaylarını girin',
      icon: FileText 
    },
    { 
      id: 2, 
      title: 'Kategorizasyon', 
      description: 'Problem kategorisi ve önem derecesi',
      icon: AlertTriangle 
    },
    { 
      id: 3, 
      title: 'Süreç Bilgileri', 
      description: 'Departman ve tarih bilgileri',
      icon: Calendar 
    },
    { 
      id: 4, 
      title: 'AI Analizi', 
      description: '8D raporu oluşturma',
      icon: Brain 
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-6">Süreç Adımları</h3>
      
      <div className="space-y-4">
        {steps.map((step, index) => {
          const Icon = step.icon;
          const isActive = currentStep === step.id;
          const isCompleted = currentStep > step.id;
          const isAccessible = currentStep >= step.id;

          return (
            <div key={step.id} className="flex items-start space-x-3">
              <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-200 ${
                isCompleted 
                  ? 'bg-green-500 text-white' 
                  : isActive 
                    ? 'bg-blue-500 text-white' 
                    : isAccessible 
                      ? 'bg-gray-200 text-gray-600' 
                      : 'bg-gray-100 text-gray-400'
              }`}>
                {isCompleted ? (
                  <Check className="w-5 h-5" />
                ) : (
                  <Icon className="w-4 h-4" />
                )}
              </div>
              
              <div className="flex-1 min-w-0">
                <h4 className={`text-sm font-medium transition-colors duration-200 ${
                  isActive ? 'text-blue-600' : isCompleted ? 'text-green-600' : 'text-gray-700'
                }`}>
                  {step.title}
                </h4>
                <p className={`text-xs mt-1 transition-colors duration-200 ${
                  isActive ? 'text-blue-500' : isCompleted ? 'text-green-500' : 'text-gray-500'
                }`}>
                  {step.description}
                </p>
              </div>
              
              {index < steps.length - 1 && (
                <div className={`w-px h-8 ml-4 mt-2 transition-colors duration-200 ${
                  isCompleted ? 'bg-green-300' : 'bg-gray-200'
                }`} />
              )}
            </div>
          );
        })}
      </div>
      
      <div className="mt-8 p-4 bg-blue-50 rounded-lg border border-blue-200">
        <h4 className="text-sm font-semibold text-blue-900 mb-2">8D Metodolojisi</h4>
        <p className="text-xs text-blue-700 leading-relaxed">
          Sekiz Disiplin (8D) problemi çözmek için sistematik bir yaklaşımdır. 
          Her adım önemli olup, kalıcı çözümler için takip edilmelidir.
        </p>
      </div>
    </div>
  );
};

export default ProgressSteps;
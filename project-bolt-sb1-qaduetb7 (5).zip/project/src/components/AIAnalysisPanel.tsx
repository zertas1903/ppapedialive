import React, { useState } from 'react';
import { Brain, Download, Eye, EyeOff, AlertTriangle, CheckCircle, Target, Users, Search, Wrench, Shield, Award, BookOpen, Lightbulb } from 'lucide-react';

interface AIAnalysisPanelProps {
  analysis: any;
}

const AIAnalysisPanel: React.FC<AIAnalysisPanelProps> = ({ analysis }) => {
  const [activeTab, setActiveTab] = useState<'summary' | '8d'>('summary');
  const [expanded8D, setExpanded8D] = useState<string[]>([]);

  const toggle8D = (discipline: string) => {
    setExpanded8D(prev => 
      prev.includes(discipline) 
        ? prev.filter(d => d !== discipline)
        : [...prev, discipline]
    );
  };

  const disciplines = [
    { key: 'd1', title: 'D1: Takım Oluşturma', icon: Users, color: 'blue' },
    { key: 'd2', title: 'D2: Problem Tanımı', icon: AlertTriangle, color: 'red' },
    { key: 'd3', title: 'D3: Geçici Önlemler', icon: Shield, color: 'yellow' },
    { key: 'd4', title: 'D4: Kök Neden Analizi', icon: Search, color: 'purple' },
    { key: 'd5', title: 'D5: Düzeltici Eylemler', icon: Target, color: 'green' },
    { key: 'd6', title: 'D6: Eylemleri Uygulama', icon: Wrench, color: 'indigo' },
    { key: 'd7', title: 'D7: Tekrarını Önleme', icon: CheckCircle, color: 'teal' },
    { key: 'd8', title: 'D8: Takımı Kutlama', icon: Award, color: 'pink' }
  ];

  const getColorClasses = (color: string, type: 'bg' | 'text' | 'border') => {
    const colorMap: Record<string, Record<string, string>> = {
      blue: { bg: 'bg-blue-500', text: 'text-blue-600', border: 'border-blue-200' },
      red: { bg: 'bg-red-500', text: 'text-red-600', border: 'border-red-200' },
      yellow: { bg: 'bg-yellow-500', text: 'text-yellow-600', border: 'border-yellow-200' },
      purple: { bg: 'bg-purple-500', text: 'text-purple-600', border: 'border-purple-200' },
      green: { bg: 'bg-green-500', text: 'text-green-600', border: 'border-green-200' },
      indigo: { bg: 'bg-indigo-500', text: 'text-indigo-600', border: 'border-indigo-200' },
      teal: { bg: 'bg-teal-500', text: 'text-teal-600', border: 'border-teal-200' },
      pink: { bg: 'bg-pink-500', text: 'text-pink-600', border: 'border-pink-200' }
    };
    return colorMap[color]?.[type] || colorMap.blue[type];
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <div className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="bg-blue-600 p-2 rounded-lg mr-3">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div>
              <h3 className="text-xl font-semibold text-gray-900">AI Analiz Raporu</h3>
              <p className="text-gray-600">Güven Skoru: {analysis.confidence}%</p>
            </div>
          </div>
          
          <div className="flex space-x-2">
            <button className="px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors duration-200 flex items-center">
              <Download className="w-4 h-4 mr-2" />
              PDF İndir
            </button>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex border-b border-gray-200">
        <button
          onClick={() => setActiveTab('summary')}
          className={`flex-1 px-6 py-4 text-center font-medium transition-colors duration-200 ${
            activeTab === 'summary'
              ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-500'
              : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
          }`}
        >
          Özet Rapor
        </button>
        <button
          onClick={() => setActiveTab('8d')}
          className={`flex-1 px-6 py-4 text-center font-medium transition-colors duration-200 ${
            activeTab === '8d'
              ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-500'
              : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
          }`}
        >
          8D Detay Raporu
        </button>
      </div>

      <div className="p-6">
        {activeTab === 'summary' && (
          <div className="space-y-6">
            {/* Problem Type */}
            <div>
              <h4 className="text-lg font-semibold text-gray-900 mb-3">Problem Tipi</h4>
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="text-red-800 font-medium">{analysis.problemType}</p>
              </div>
            </div>

            {/* Root Cause */}
            <div>
              <h4 className="text-lg font-semibold text-gray-900 mb-3">Kök Neden</h4>
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                <p className="text-purple-800">{analysis.rootCause}</p>
              </div>
            </div>

            {/* Immediate Actions */}
            <div>
              <h4 className="text-lg font-semibold text-gray-900 mb-3">Acil Eylemler</h4>
              <div className="space-y-2">
                {analysis.immediateActions.map((action: string, index: number) => (
                  <div key={index} className="flex items-start space-x-3 bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                    <CheckCircle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
                    <span className="text-yellow-800">{action}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Recommendations */}
            <div>
              <h4 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                <Lightbulb className="w-5 h-5 mr-2 text-yellow-500" />
                Mühendislik Önerileri
              </h4>
              <div className="space-y-2">
                {analysis.recommendations.map((rec: string, index: number) => (
                  <div key={index} className="flex items-start space-x-3 bg-green-50 border border-green-200 rounded-lg p-3">
                    <Target className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
                    <span className="text-green-800">{rec}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Technical Insights */}
            <div>
              <h4 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                <BookOpen className="w-5 h-5 mr-2 text-blue-500" />
                Teknik Bilgiler
              </h4>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-blue-800 text-sm leading-relaxed">
                  Bu analiz, gerçek mühendislik deneyimlerine dayalı 400+ kök neden ve çözüm veritabanından 
                  türetilmiştir. Plastik enjeksiyon, boyama, deri kaplama, poliüretan ve metal işleme 
                  süreçlerindeki yaygın kalite problemleri dikkate alınarak oluşturulmuştur.
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === '8d' && (
          <div className="space-y-4">
            {disciplines.map(({ key, title, icon: Icon, color }) => {
              const isExpanded = expanded8D.includes(key);
              const content = analysis.eightD[key];
              
              return (
                <div key={key} className={`border rounded-lg ${getColorClasses(color, 'border')}`}>
                  <button
                    onClick={() => toggle8D(key)}
                    className="w-full px-6 py-4 flex items-center justify-between text-left hover:bg-gray-50 transition-colors duration-200"
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg ${getColorClasses(color, 'bg')} text-white`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <span className="font-medium text-gray-900">{title}</span>
                    </div>
                    {isExpanded ? (
                      <EyeOff className="w-5 h-5 text-gray-400" />
                    ) : (
                      <Eye className="w-5 h-5 text-gray-400" />
                    )}
                  </button>
                  
                  {isExpanded && (
                    <div className="px-6 pb-4">
                      <div className="bg-gray-50 rounded-lg p-4 border-t border-gray-200">
                        <p className="text-gray-700 whitespace-pre-line">{content}</p>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default AIAnalysisPanel;
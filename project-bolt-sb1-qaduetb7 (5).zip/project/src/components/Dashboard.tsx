import React from 'react';
import { TrendingUp, AlertTriangle, CheckCircle, Clock, Brain, Star } from 'lucide-react';
import { useAIAnalyses, useAIStats } from '../hooks/useAIAnalyses';
import RealTimeIndicator from './RealTimeIndicator';

const Dashboard: React.FC = () => {
  const { analyses, loading, error } = useAIAnalyses();
  const aiStats = useAIStats();

  const stats = [
    { 
      title: 'Toplam Problem', 
      value: aiStats.totalAnalyses.toString(), 
      change: '+12%', 
      changeType: 'increase' as const,
      icon: AlertTriangle,
      color: 'red'
    },
    { 
      title: 'Çözülen Problem', 
      value: aiStats.completedAnalyses.toString(), 
      change: '+8%', 
      changeType: 'increase' as const,
      icon: CheckCircle,
      color: 'green'
    },
    { 
      title: 'Devam Eden', 
      value: (aiStats.totalAnalyses - aiStats.completedAnalyses).toString(), 
      change: '+4%', 
      changeType: 'increase' as const,
      icon: Clock,
      color: 'yellow'
    },
    { 
      title: 'Ortalama Çözüm Süresi', 
      value: `${aiStats.averageRating}/5 puan`, 
      change: '-2.1 gün', 
      changeType: 'decrease' as const,
      icon: TrendingUp,
      color: 'blue'
    }
  ];

  const getColorClasses = (color: string) => {
    const colorMap: Record<string, { bg: string; text: string; border: string }> = {
      red: { bg: 'bg-red-500', text: 'text-red-600', border: 'border-red-200' },
      green: { bg: 'bg-green-500', text: 'text-green-600', border: 'border-green-200' },
      yellow: { bg: 'bg-yellow-500', text: 'text-yellow-600', border: 'border-yellow-200' },
      blue: { bg: 'bg-blue-500', text: 'text-blue-600', border: 'border-blue-200' }
    };
    return colorMap[color] || colorMap.blue;
  };

  return (
    <div className="space-y-8">
      <RealTimeIndicator />
      
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Dashboard</h2>
        <p className="text-gray-600 mt-1">Problem çözme süreçlerinizin genel durumu</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          const colors = getColorClasses(stat.color);
          
          return (
            <div key={index} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div className={`p-3 rounded-lg ${colors.bg}`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <span className={`text-sm font-medium ${
                  stat.changeType === 'increase' 
                    ? stat.color === 'red' ? 'text-red-600' : 'text-green-600'
                    : 'text-green-600'
                }`}>
                  {stat.change}
                </span>
              </div>
              
              <div className="mt-4">
                <h3 className="text-2xl font-bold text-gray-900">{stat.value}</h3>
                <p className="text-gray-600 text-sm mt-1">{stat.title}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Loading and Error States */}
      {loading && (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Veriler yükleniyor...</p>
        </div>
      )}
      
      {error && <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-800">{error}</div>}
      
      {/* Demo Mode Info */}
      {!loading && !error && analyses.length > 0 && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-blue-800 text-sm">
            ℹ️ Demo modu aktif - Örnek veriler gösteriliyor. Gerçek veriler için Supabase bağlantısı yapılandırın.
          </p>
        </div>
      )}

      {/* Recent Analyses */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center">
            <Brain className="w-5 h-5 text-blue-600 mr-2" />
            <h3 className="text-lg font-semibold text-gray-900">Son AI Analizleri</h3>
          </div>
        </div>
        
        <div className="p-6">
          <div className="space-y-4">
            {analyses.slice(0, 5).map((analysis) => (
              <div key={analysis.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900">{analysis.title}</h4>
                  <p className="text-sm text-gray-600 mt-1">{analysis.category} • {new Date(analysis.created_at).toLocaleDateString('tr-TR')}</p>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i}
                        className={`w-4 h-4 ${
                          i < analysis.rating ? 'text-yellow-500 fill-current' : 'text-gray-300'
                        }`}
                      />
                    ))}
                  </div>
                  
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    analysis.status === 'completed'
                      ? 'bg-green-100 text-green-800'
                      : 'bg-yellow-100 text-yellow-800'
                  }`}>
                    {analysis.status === 'completed' ? 'Tamamlandı' : 'Devam Ediyor'}
                  </span>
                </div>
              </div>
            ))}
          </div>
          
          {analyses.length === 0 && !loading && (
            <p className="text-center text-gray-500 py-8">Henüz analiz bulunmuyor.</p>
          )}
        </div>
      </div>

      {/* AI Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">AI Performansı</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-600">Mühendislik Veritabanı Eşleşme</span>
                <span className="font-medium">{aiStats.averageConfidence}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-green-500 h-2 rounded-full" style={{ width: `${aiStats.averageConfidence}%` }}></div>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-600">Kullanıcı Memnuniyeti</span>
                <span className="font-medium">{aiStats.averageRating}/5</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-500 h-2 rounded-full" style={{ width: `${(aiStats.averageRating / 5) * 100}%` }}></div>
              </div>
            </div>
            
            <div>
              <div className="flex justify-between text-sm mb-2">
                <span className="text-gray-600">Teknik Doğruluk</span>
                <span className="font-medium">{Math.min(aiStats.averageConfidence + 5, 100)}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-purple-500 h-2 rounded-full" style={{ width: `${Math.min(aiStats.averageConfidence + 5, 100)}%` }}></div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Problem Kategorileri</h3>
          <div className="space-y-3">
            {[
              { category: 'Plastik Enjeksiyon', count: analyses.filter(a => a.category.includes('Plastik')).length, percentage: 35 },
              { category: 'Boyalı Plastik', count: 28, percentage: 22 },
              { category: 'Deri Kaplama', count: 22, percentage: 17 },
              { category: 'Poliüretan', count: 18, percentage: 14 },
              { category: 'Metal Braket', count: 15, percentage: 12 }
            ].map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className={`w-3 h-3 rounded-full mr-3 bg-${['blue', 'green', 'yellow', 'red', 'purple'][index]}-500`}></div>
                  <span className="text-sm text-gray-700">{item.category}</span>
                </div>
                <div className="text-sm text-gray-900 font-medium">{item.count}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
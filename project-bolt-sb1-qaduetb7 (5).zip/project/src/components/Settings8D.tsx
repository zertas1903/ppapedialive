import React, { useState } from 'react';
import { Settings, Brain, Key, Database, Zap, Save, AlertCircle } from 'lucide-react';

const Settings8D: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'ai' | 'integrations' | 'general'>('ai');
  const [settings, setSettings] = useState({
    aiProvider: 'openai',
    apiKey: '',
    analysisDepth: 'detailed',
    autoSave: true,
    notificationsEnabled: true,
    confidenceThreshold: 75,
    language: 'tr'
  });

  const handleInputChange = (key: string, value: string | boolean | number) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const saveSettings = () => {
    // Here you would save settings to your database
    console.log('Settings saved:', settings);
    // Show success message
  };

  const tabs = [
    { id: 'ai' as const, label: 'AI Ayarları', icon: Brain },
    { id: 'integrations' as const, label: 'Entegrasyonlar', icon: Zap },
    { id: 'general' as const, label: 'Genel', icon: Settings }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Ayarlar</h2>
        <p className="text-gray-600 mt-1">8D Problem Solver uygulamanızı kişiselleştirin</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <nav className="space-y-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center px-3 py-2 text-left rounded-lg transition-colors duration-200 ${
                      activeTab === tab.id
                        ? 'bg-blue-50 text-blue-600 border border-blue-200'
                        : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="w-4 h-4 mr-3" />
                    {tab.label}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Content */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            {activeTab === 'ai' && (
              <div className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-6">AI Ayarları</h3>
                
                <div className="space-y-6">
                  {/* AI Provider */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      AI Sağlayıcısı
                    </label>
                    <select
                      value={settings.aiProvider}
                      onChange={(e) => handleInputChange('aiProvider', e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="openai">OpenAI GPT-4</option>
                      <option value="claude">Anthropic Claude</option>
                      <option value="gemini">Google Gemini</option>
                      <option value="grok">X.AI Grok</option>
                      <option value="engineering_db">Mühendislik Veritabanı (Yerel)</option>
                    </select>
                    <p className="text-xs text-gray-500 mt-1">
                      Problem analizi için kullanılacak AI modeli. Mühendislik Veritabanı seçeneği 400+ gerçek kök neden içerir.
                    </p>
                  </div>

                  {/* API Key */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      API Anahtarı
                    </label>
                    <div className="relative">
                      <Key className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                      <input
                        type="password"
                        value={settings.apiKey}
                        onChange={(e) => handleInputChange('apiKey', e.target.value)}
                        className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="API anahtarınızı girin"
                      />
                    </div>
                    <div className="flex items-start mt-2">
                      <AlertCircle className="w-4 h-4 text-amber-500 mr-2 mt-0.5 flex-shrink-0" />
                      <p className="text-xs text-amber-600">
                        API anahtarınız güvenli şekilde şifrelenerek saklanır. Sadece AI analizleri için kullanılır.
                      </p>
                    </div>
                  </div>

                  {/* Analysis Depth */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Analiz Derinliği
                    </label>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      {[
                        { value: 'quick', label: 'Hızlı', description: 'Temel analiz, 30 saniye' },
                        { value: 'standard', label: 'Standart', description: 'Kapsamlı analiz, 1-2 dakika' },
                        { value: 'detailed', label: 'Detaylı', description: 'Derinlemesine analiz, 3-5 dakika' }
                      ].map((option) => (
                        <button
                          key={option.value}
                          onClick={() => handleInputChange('analysisDepth', option.value)}
                          className={`p-4 border rounded-lg text-left transition-colors duration-200 ${
                            settings.analysisDepth === option.value
                              ? 'border-blue-500 bg-blue-50'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                        >
                          <div className="font-medium text-gray-900">{option.label}</div>
                          <div className="text-sm text-gray-600 mt-1">{option.description}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Confidence Threshold */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Güven Eşiği: {settings.confidenceThreshold}%
                    </label>
                    <input
                      type="range"
                      min="50"
                      max="95"
                      value={settings.confidenceThreshold}
                      onChange={(e) => handleInputChange('confidenceThreshold', parseInt(e.target.value))}
                      className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                    />
                    <div className="flex justify-between text-xs text-gray-500 mt-1">
                      <span>Düşük Güven (50%)</span>
                      <span>Yüksek Güven (95%)</span>
                    </div>
                    <p className="text-xs text-gray-500 mt-2">
                      Bu değerin altındaki analizler için uyarı gösterilir
                    </p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'integrations' && (
              <div className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-6">Entegrasyonlar</h3>
                
                <div className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {[
                      {
                        name: 'Supabase Database',
                        description: 'Raporları ve analizleri kaydetmek için',
                        icon: Database,
                        status: 'connected',
                        color: 'green'
                      },
                      {
                        name: 'OpenAI API',
                        description: 'AI destekli problem analizi',
                        icon: Brain,
                        status: settings.apiKey ? 'connected' : 'disconnected',
                        color: settings.apiKey ? 'green' : 'red'
                      },
                      {
                        name: 'Email Notifications',
                        description: 'Analiz tamamlandığında bildirim',
                        icon: Zap,
                        status: settings.notificationsEnabled ? 'enabled' : 'disabled',
                        color: settings.notificationsEnabled ? 'blue' : 'gray'
                      }
                    ].map((integration, index) => {
                      const Icon = integration.icon;
                      return (
                        <div key={index} className="border border-gray-200 rounded-lg p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex items-start space-x-3">
                              <div className={`p-2 rounded-lg bg-${integration.color}-100`}>
                                <Icon className={`w-5 h-5 text-${integration.color}-600`} />
                              </div>
                              <div>
                                <h4 className="font-medium text-gray-900">{integration.name}</h4>
                                <p className="text-sm text-gray-600 mt-1">{integration.description}</p>
                              </div>
                            </div>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              integration.status === 'connected' ? 'bg-green-100 text-green-800' :
                              integration.status === 'enabled' ? 'bg-blue-100 text-blue-800' :
                              integration.status === 'disabled' ? 'bg-gray-100 text-gray-800' :
                              'bg-red-100 text-red-800'
                            }`}>
                              {integration.status === 'connected' ? 'Bağlı' :
                               integration.status === 'enabled' ? 'Aktif' :
                               integration.status === 'disabled' ? 'Pasif' : 'Bağlı Değil'}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'general' && (
              <div className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-6">Genel Ayarlar</h3>
                
                <div className="space-y-6">
                  {/* Language */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Dil
                    </label>
                    <select
                      value={settings.language}
                      onChange={(e) => handleInputChange('language', e.target.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="tr">Türkçe</option>
                      <option value="en">English</option>
                      <option value="de">Deutsch</option>
                      <option value="fr">Français</option>
                    </select>
                  </div>

                  {/* Auto Save */}
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-medium text-gray-700">Otomatik Kaydetme</h4>
                      <p className="text-sm text-gray-600">Analizleri otomatik olarak kaydet</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.autoSave}
                        onChange={(e) => handleInputChange('autoSave', e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>

                  {/* Notifications */}
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-sm font-medium text-gray-700">Bildirimler</h4>
                      <p className="text-sm text-gray-600">Analiz tamamlandığında bildirim gönder</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settings.notificationsEnabled}
                        onChange={(e) => handleInputChange('notificationsEnabled', e.target.checked)}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* Save Button */}
            <div className="px-6 py-4 border-t border-gray-200 bg-gray-50 rounded-b-lg">
              <button
                onClick={saveSettings}
                className="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center justify-center"
              >
                <Save className="w-4 h-4 mr-2" />
                Ayarları Kaydet
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings8D;
import React, { useState, useEffect } from 'react';
import { PowerBIEmbed } from 'powerbi-client-react';
import { models } from 'powerbi-client';
import { BarChart3, Settings, RefreshCw, Maximize2, Download, Eye, EyeOff } from 'lucide-react';

interface PowerBIConfig {
  embedUrl: string;
  accessToken: string;
  reportId: string;
  groupId?: string;
}

const PowerBIDashboard: React.FC = () => {
  const [config, setConfig] = useState<PowerBIConfig>({
    embedUrl: '',
    accessToken: '',
    reportId: '',
    groupId: ''
  });
  
  const [isConfigured, setIsConfigured] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Demo konfigürasyonu - gerçek uygulamada environment variables'dan gelecek
  const demoConfig = {
    embedUrl: 'https://app.powerbi.com/reportEmbed?reportId=DEMO_REPORT_ID',
    accessToken: 'DEMO_ACCESS_TOKEN',
    reportId: 'DEMO_REPORT_ID',
    groupId: 'DEMO_GROUP_ID'
  };

  const handleConfigSave = () => {
    if (!config.embedUrl || !config.accessToken || !config.reportId) {
      setError('Lütfen tüm zorunlu alanları doldurun!');
      return;
    }
    
    setIsConfigured(true);
    setShowSettings(false);
    setError(null);
    
    // Konfigürasyonu localStorage'a kaydet
    localStorage.setItem('powerbi_config', JSON.stringify(config));
  };

  const loadDemoConfig = () => {
    setConfig(demoConfig);
    setError('Demo konfigürasyonu yüklendi. Gerçek Power BI raporu için kendi bilgilerinizi girin.');
  };

  useEffect(() => {
    // Sayfa yüklendiğinde kaydedilmiş konfigürasyonu kontrol et
    const savedConfig = localStorage.getItem('powerbi_config');
    if (savedConfig) {
      try {
        const parsedConfig = JSON.parse(savedConfig);
        setConfig(parsedConfig);
        setIsConfigured(true);
      } catch (err) {
        console.error('Kaydedilmiş konfigürasyon yüklenemedi:', err);
      }
    }
  }, []);

  const powerBIConfig = {
    type: 'report',
    id: config.reportId,
    embedUrl: config.embedUrl,
    accessToken: config.accessToken,
    tokenType: models.TokenType.Embed,
    settings: {
      panes: {
        filters: {
          expanded: false,
          visible: true
        },
        pageNavigation: {
          visible: true
        }
      },
      background: models.BackgroundType.Transparent,
      layoutType: models.LayoutType.FitToWidth
    }
  };

  if (!isConfigured) {
    return (
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Power BI Dashboard</h2>
          <p className="text-gray-600 mt-1">Power BI raporlarınızı entegre edin</p>
        </div>

        {/* Configuration Card */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
          <div className="text-center mb-8">
            <div className="bg-blue-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <BarChart3 className="w-8 h-8 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Power BI Entegrasyonu</h3>
            <p className="text-gray-600">
              Power BI dashboard'larınızı bu sayfada görüntülemek için konfigürasyon yapın
            </p>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-red-800 text-sm">{error}</p>
            </div>
          )}

          <div className="space-y-4 max-w-2xl mx-auto">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Embed URL *
              </label>
              <input
                type="url"
                value={config.embedUrl}
                onChange={(e) => setConfig(prev => ({ ...prev, embedUrl: e.target.value }))}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="https://app.powerbi.com/reportEmbed?reportId=..."
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Access Token *
              </label>
              <textarea
                value={config.accessToken}
                onChange={(e) => setConfig(prev => ({ ...prev, accessToken: e.target.value }))}
                rows={3}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                placeholder="Power BI access token'ınızı buraya yapıştırın"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Report ID *
                </label>
                <input
                  type="text"
                  value={config.reportId}
                  onChange={(e) => setConfig(prev => ({ ...prev, reportId: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="12345678-1234-1234-1234-123456789012"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Group ID (Workspace)
                </label>
                <input
                  type="text"
                  value={config.groupId}
                  onChange={(e) => setConfig(prev => ({ ...prev, groupId: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="12345678-1234-1234-1234-123456789012"
                />
              </div>
            </div>

            <div className="flex items-center justify-center space-x-4 pt-6">
              <button
                onClick={loadDemoConfig}
                className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors duration-200"
              >
                Demo Yükle
              </button>
              
              <button
                onClick={handleConfigSave}
                className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 flex items-center"
              >
                <Settings className="w-4 h-4 mr-2" />
                Kaydet ve Başlat
              </button>
            </div>
          </div>

          {/* Instructions */}
          <div className="mt-8 p-6 bg-blue-50 rounded-lg border border-blue-200">
            <h4 className="text-lg font-semibold text-blue-900 mb-4">Nasıl Yapılandırılır?</h4>
            <div className="space-y-3 text-sm text-blue-800">
              <div className="flex items-start">
                <span className="bg-blue-200 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold mr-3 mt-0.5">1</span>
                <div>
                  <strong>Power BI Service'e gidin:</strong> app.powerbi.com
                </div>
              </div>
              <div className="flex items-start">
                <span className="bg-blue-200 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold mr-3 mt-0.5">2</span>
                <div>
                  <strong>Raporunuzu açın</strong> ve "File" → "Embed report" → "Website or portal" seçin
                </div>
              </div>
              <div className="flex items-start">
                <span className="bg-blue-200 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold mr-3 mt-0.5">3</span>
                <div>
                  <strong>Embed URL'i kopyalayın</strong> ve yukarıdaki forma yapıştırın
                </div>
              </div>
              <div className="flex items-start">
                <span className="bg-blue-200 text-blue-800 rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold mr-3 mt-0.5">4</span>
                <div>
                  <strong>Access Token alın:</strong> Power BI REST API'den veya Power BI Embedded kullanın
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Power BI Dashboard</h2>
          <p className="text-gray-600 mt-1">Canlı raporlarınızı görüntüleyin</p>
        </div>
        
        <div className="flex items-center space-x-3">
          <button
            onClick={() => setIsLoading(true)}
            className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Yenile
          </button>
          
          <button
            onClick={() => setShowSettings(true)}
            className="flex items-center px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors duration-200"
          >
            <Settings className="w-4 h-4 mr-2" />
            Ayarlar
          </button>
        </div>
      </div>

      {/* Power BI Embed */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="h-[800px] relative">
          {config.accessToken === 'DEMO_ACCESS_TOKEN' ? (
            // Demo görünümü
            <div className="h-full flex items-center justify-center bg-gradient-to-br from-blue-50 to-purple-50">
              <div className="text-center p-8">
                <BarChart3 className="w-24 h-24 text-blue-400 mx-auto mb-6" />
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Power BI Dashboard Demo</h3>
                <p className="text-gray-600 mb-6 max-w-md">
                  Gerçek Power BI dashboard'ınız burada görünecek. 
                  Konfigürasyonu tamamlamak için ayarlar butonuna tıklayın.
                </p>
                <div className="grid grid-cols-2 gap-4 max-w-sm mx-auto">
                  <div className="bg-white p-4 rounded-lg shadow-sm border">
                    <div className="text-2xl font-bold text-blue-600">127</div>
                    <div className="text-sm text-gray-600">Toplam Görev</div>
                  </div>
                  <div className="bg-white p-4 rounded-lg shadow-sm border">
                    <div className="text-2xl font-bold text-green-600">89%</div>
                    <div className="text-sm text-gray-600">Tamamlanma</div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            // Gerçek Power BI embed
            <PowerBIEmbed
              embedConfig={powerBIConfig}
              eventHandlers={new Map([
                ['loaded', () => setIsLoading(false)],
                ['rendered', () => setIsLoading(false)],
                ['error', (event) => {
                  console.error('Power BI Error:', event.detail);
                  setError('Power BI raporu yüklenirken hata oluştu.');
                  setIsLoading(false);
                }]
              ])}
              cssClassName="powerbi-embed"
              getEmbeddedComponent={(embeddedReport) => {
                // Embedded component referansını saklayabilirsiniz
                console.log('Power BI component loaded:', embeddedReport);
              }}
            />
          )}
          
          {isLoading && (
            <div className="absolute inset-0 bg-white bg-opacity-75 flex items-center justify-center">
              <div className="text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p className="text-gray-600">Power BI raporu yükleniyor...</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-semibold text-gray-900">Power BI Ayarları</h3>
                <button
                  onClick={() => setShowSettings(false)}
                  className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200"
                >
                  <EyeOff className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Embed URL
                </label>
                <input
                  type="url"
                  value={config.embedUrl}
                  onChange={(e) => setConfig(prev => ({ ...prev, embedUrl: e.target.value }))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Access Token
                </label>
                <textarea
                  value={config.accessToken}
                  onChange={(e) => setConfig(prev => ({ ...prev, accessToken: e.target.value }))}
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Report ID
                  </label>
                  <input
                    type="text"
                    value={config.reportId}
                    onChange={(e) => setConfig(prev => ({ ...prev, reportId: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Group ID
                  </label>
                  <input
                    type="text"
                    value={config.groupId}
                    onChange={(e) => setConfig(prev => ({ ...prev, groupId: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end space-x-4 pt-6 border-t border-gray-200">
                <button
                  onClick={() => {
                    setIsConfigured(false);
                    setShowSettings(false);
                  }}
                  className="px-6 py-3 border border-red-300 text-red-700 rounded-lg hover:bg-red-50 transition-colors duration-200"
                >
                  Konfigürasyonu Sıfırla
                </button>
                
                <button
                  onClick={handleConfigSave}
                  className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
                >
                  Kaydet
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PowerBIDashboard;
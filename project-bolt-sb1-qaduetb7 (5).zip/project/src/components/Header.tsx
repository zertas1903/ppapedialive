import React from 'react';
import { Cog, Sparkles, ArrowLeft, CheckSquare, Brain } from 'lucide-react';
import UserProfile from './UserProfile';

interface HeaderProps {
  appMode?: 'landing' | '8d' | 'work';
  onModeChange?: (mode: 'landing' | '8d' | 'work') => void;
  username?: string;
  onLogout?: () => void;
}

const Header: React.FC<HeaderProps> = ({ appMode = 'landing', onModeChange, username, onLogout }) => {
  const getHeaderContent = () => {
    switch (appMode) {
      case '8d':
        return {
          title: 'PPAPedia',
          subtitle: '8D Problem Solver - AI Destekli Kalite Mühendisliği',
          gradient: 'from-purple-600 to-pink-600'
        };
      case 'work':
        return {
          title: 'PPAPedia',
          subtitle: 'İş Takip Sistemi - Akıllı Proje Yönetimi',
          gradient: 'from-blue-600 to-cyan-600'
        };
      case 'calculations':
        return {
          title: 'PPAPedia',
          subtitle: 'Hesaplamalar - Cp/Cpk Analizi',
          gradient: 'from-green-600 to-teal-600'
        };
      default:
        return {
          title: 'PPAPedia',
          subtitle: 'AI Powered Quality Engineering Platform',
          gradient: 'from-blue-600 to-purple-600'
        };
    }
  };

  const headerContent = getHeaderContent();

  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            {appMode !== 'landing' && onModeChange && (
              <button
                onClick={() => onModeChange('landing')}
                className="mr-4 p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors duration-200"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
            )}
            
            <div className="flex-shrink-0 flex items-center">
              <div className="mr-3">
                <img 
                  src="/ppapedia-logo.png"
                  alt="PPAPedia Logo" 
                  className="h-10 w-10 object-contain"
                />
              </div>
              <div>
                <h1 className={`text-xl font-bold bg-gradient-to-r ${headerContent.gradient} bg-clip-text text-transparent`}>
                  {headerContent.title}
                </h1>
                <p className="text-sm text-gray-600">{headerContent.subtitle}</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {appMode !== 'landing' && onModeChange && (
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => onModeChange(appMode === '8d' ? 'work' : '8d')}
                  className={`flex items-center px-3 py-1 rounded-full text-sm font-medium transition-colors duration-200 ${
                    appMode === '8d' 
                      ? 'bg-blue-100 text-blue-700 hover:bg-blue-200' 
                      : 'bg-purple-100 text-purple-700 hover:bg-purple-200'
                  }`}
                >
                  {appMode === '8d' ? (
                    <>
                      <CheckSquare className="w-4 h-4 mr-1" />
                      İş Takibi
                    </>
                  ) : (
                    <>
                      <Brain className="w-4 h-4 mr-1" />
                      8D Analiz
                    </>
                  )}
                </button>
              </div>
            )}
            
            <div className="flex items-center bg-gradient-to-r from-purple-500 to-pink-500 text-white px-3 py-1 rounded-full text-sm">
              <Sparkles className="w-4 h-4 mr-1" />
              AI Powered
            </div>
            
            {username && onLogout && (
              <UserProfile username={username} onLogout={onLogout} />
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
import React, { useState } from 'react';
import { Search, Filter, Download, Eye, Calendar, Star, Trash2 } from 'lucide-react';
import { useAIAnalyses } from '../hooks/useAIAnalyses';
import RealTimeIndicator from './RealTimeIndicator';

const ReportHistory: React.FC = () => {
  const { analyses, loading, error, updateAnalysisRating } = useAIAnalyses();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [sortBy, setSortBy] = useState('date');

  const filteredReports = analyses.filter(report => {
    const matchesSearch = report.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         report.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterCategory === 'all' || report.category.toLowerCase().includes(filterCategory);
    return matchesSearch && matchesFilter;
  });

  const sortedReports = [...filteredReports].sort((a, b) => {
    switch (sortBy) {
      case 'date':
        return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      case 'rating':
        return b.rating - a.rating;
      case 'confidence':
        return (b.analysis_result?.confidence || 0) - (a.analysis_result?.confidence || 0);
      default:
        return 0;
    }
  });

  const getSeverityColor = (severity: string) => {
    const colorMap: Record<string, string> = {
      critical: 'bg-red-100 text-red-800',
      high: 'bg-orange-100 text-orange-800',
      medium: 'bg-yellow-100 text-yellow-800',
      low: 'bg-green-100 text-green-800'
    };
    return colorMap[severity] || colorMap.medium;
  };

  const getStatusColor = (status: string) => {
    return status === 'completed' 
      ? 'bg-green-100 text-green-800' 
      : 'bg-blue-100 text-blue-800';
  };

  const handleRatingUpdate = async (analysisId: string, newRating: number) => {
    try {
      await updateAnalysisRating(analysisId, newRating);
    } catch (error) {
      console.error('Rating güncellenirken hata:', error);
    }
  };

  return (
    <div className="space-y-6">
      <RealTimeIndicator />
      
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Rapor Geçmişi</h2>
        <p className="text-gray-600 mt-1">Tüm 8D analizlerinizi görüntüleyin ve yönetin</p>
      </div>

      {/* Filters and Search */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
            <input
              type="text"
              placeholder="Rapor ara..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div className="relative">
            <Filter className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none"
            >
              <option value="all">Tüm Kategoriler</option>
              <option value="kalite">Kalite Hatası</option>
              <option value="süreç">Süreç Hatası</option>
              <option value="ekipman">Ekipman Hatası</option>
              <option value="insan">İnsan Hatası</option>
              <option value="malzeme">Malzeme Hatası</option>
              <option value="çevre">Çevre Hatası</option>
            </select>
          </div>

          <div className="relative">
            <Calendar className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none"
            >
              <option value="date">Tarihe Göre</option>
              <option value="rating">Puana Göre</option>
              <option value="confidence">Güven Skoruna Göre</option>
            </select>
          </div>
        </div>
      </div>

      {/* Loading and Error States */}
      {loading && (
        <div className="text-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Raporlar yükleniyor...</p>
        </div>
      )}
      
      {error && <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-800">{error}</div>}
      
      {/* Demo Mode Info */}
      {!loading && !error && sortedReports.length > 0 && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <p className="text-blue-800 text-sm">
            ℹ️ Demo modu aktif - Örnek raporlar gösteriliyor. Gerçek veriler için Supabase bağlantısı yapılandırın.
          </p>
        </div>
      )}

      {/* Reports List */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">
              Raporlar ({sortedReports.length})
            </h3>
            <button className="flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors duration-200">
              <Download className="w-4 h-4 mr-2" />
              Toplu İndir
            </button>
          </div>
        </div>

        <div className="divide-y divide-gray-200">
          {sortedReports.map((report) => (
            <div key={report.id} className="p-6 hover:bg-gray-50 transition-colors duration-200">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-start space-x-4">
                    <div className="flex-1">
                      <h4 className="text-lg font-medium text-gray-900 mb-2">{report.title}</h4>
                      
                      <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                        <span className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {new Date(report.created_at).toLocaleDateString('tr-TR')}
                        </span>
                        <span>{report.category}</span>
                        <span>Güven: {report.analysis_result?.confidence || report.confidence}%</span>
                      </div>

                      <div className="flex items-center space-x-3">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getSeverityColor('medium')}`}>
                          {report.confidence >= 90 ? 'Yüksek Güven' : 
                           report.confidence >= 70 ? 'Orta Güven' : 'Düşük Güven'}
                        </span>
                        
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(report.status)}`}>
                          {report.status === 'completed' ? 'Tamamlandı' : 'Devam Ediyor'}
                        </span>

                        <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                          {report.category}
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-col items-end space-y-2">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <button
                            key={i}
                            onClick={() => handleRatingUpdate(report.id, i + 1)}
                            className="hover:scale-110 transition-transform duration-200"
                          >
                            <Star 
                            key={i}
                            className={`w-4 h-4 ${
                              i < report.rating ? 'text-yellow-500 fill-current' : 'text-gray-300'
                            }`}
                            />
                          </button>
                        ))}
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <button className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors duration-200">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-gray-400 hover:text-green-600 hover:bg-green-50 rounded-lg transition-colors duration-200">
                          <Download className="w-4 h-4" />
                        </button>
                        <button className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors duration-200">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {sortedReports.length === 0 && (
          <div className="p-12 text-center">
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Rapor Bulunamadı</h3>
            <p className="text-gray-600">Arama kriterlerinizi değiştirmeyi deneyin.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReportHistory;
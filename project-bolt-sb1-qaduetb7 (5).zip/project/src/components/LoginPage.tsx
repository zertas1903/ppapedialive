import React, { useState } from 'react';
import { User, Lock, Eye, EyeOff, Shield, AlertCircle, UserPlus, Mail, Building } from 'lucide-react';

interface LoginPageProps {
  onLogin: (username: string) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true); // true = giriş, false = üye ol
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    email: '',
    fullName: '',
    department: '',
    role: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Demo kullanıcıları - gerçek uygulamada veritabanından gelecek
  const defaultUsers = [
    { username: 'admin', password: 'admin123', role: 'Yönetici', email: 'admin@ppapedia.com', fullName: 'Sistem Yöneticisi', department: 'IT' },
    { username: 'ahmet.yilmaz', password: 'kalip2025', role: 'Kalıp Mühendisi', email: 'ahmet@ppapedia.com', fullName: 'Ahmet Yılmaz', department: 'Mühendislik' },
    { username: 'mehmet.kaya', password: 'bakim2025', role: 'Bakım Teknisyeni', email: 'mehmet@ppapedia.com', fullName: 'Mehmet Kaya', department: 'Bakım' },
    { username: 'fatma.demir', password: 'kalite2025', role: 'Kalite Mühendisi', email: 'fatma@ppapedia.com', fullName: 'Fatma Demir', department: 'Kalite' },
    { username: 'ali.ozkan', password: 'egitim2025', role: 'Eğitim Sorumlusu', email: 'ali@ppapedia.com', fullName: 'Ali Özkan', department: 'İnsan Kaynakları' },
    { username: 'zeynep.arslan', password: 'proses2025', role: 'Proses Mühendisi', email: 'zeynep@ppapedia.com', fullName: 'Zeynep Arslan', department: 'Üretim' }
  ];

  // Kayıtlı kullanıcıları localStorage'dan al
  const getRegisteredUsers = () => {
    const saved = localStorage.getItem('ppapedia_registered_users');
    return saved ? JSON.parse(saved) : [];
  };

  // Tüm kullanıcıları birleştir (demo + kayıtlı)
  const getAllUsers = () => {
    const registeredUsers = getRegisteredUsers();
    return [...defaultUsers, ...registeredUsers];
  };

  // Yeni kullanıcı kaydet
  const saveNewUser = (userData: any) => {
    const registeredUsers = getRegisteredUsers();
    registeredUsers.push(userData);
    localStorage.setItem('ppapedia_registered_users', JSON.stringify(registeredUsers));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    // Basit doğrulama
    if (!formData.username.trim() || !formData.password.trim()) {
      setError('Kullanıcı adı ve şifre gereklidir');
      setIsLoading(false);
      return;
    }

    // Kullanıcı doğrulama simülasyonu
    setTimeout(() => {
      const allUsers = getAllUsers();
      const user = allUsers.find(u => u.username === formData.username && u.password === formData.password);
      
      if (user) {
        // Başarılı giriş
        localStorage.setItem('ppapedia_user', JSON.stringify({
          username: user.username,
          role: user.role,
          email: user.email,
          fullName: user.fullName,
          department: user.department,
          loginTime: new Date().toISOString()
        }));
        onLogin(user.username);
      } else {
        setError('Kullanıcı adı veya şifre hatalı');
      }
      setIsLoading(false);
    }, 1000);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setIsLoading(true);

    // Form doğrulama
    if (!formData.username.trim() || !formData.password.trim() || !formData.email.trim() || !formData.fullName.trim()) {
      setError('Tüm zorunlu alanları doldurun');
      setIsLoading(false);
      return;
    }

    if (formData.password.length < 6) {
      setError('Şifre en az 6 karakter olmalıdır');
      setIsLoading(false);
      return;
    }

    // Email format kontrolü
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError('Geçerli bir email adresi girin');
      setIsLoading(false);
      return;
    }

    // Kullanıcı adı kontrolü
    const allUsers = getAllUsers();
    const existingUser = allUsers.find(u => u.username === formData.username);
    if (existingUser) {
      setError('Bu kullanıcı adı zaten kullanılıyor');
      setIsLoading(false);
      return;
    }

    // Üye olma simülasyonu
    setTimeout(() => {
      // Yeni kullanıcıyı kaydet
      const newUser = {
        username: formData.username,
        password: formData.password,
        email: formData.email,
        fullName: formData.fullName,
        department: formData.department || 'Genel',
        role: formData.role || 'Kullanıcı'
      };
      
      saveNewUser(newUser);
      
      setSuccess('Üyelik başarıyla oluşturuldu! Giriş yapabilirsiniz.');
      setIsLogin(true);
      setFormData({
        username: '',
        password: '',
        email: '',
        fullName: '',
        department: '',
        role: ''
      });
      setIsLoading(false);
    }, 1500);
  };

  const resetForm = () => {
    setFormData({
      username: '',
      password: '',
      email: '',
      fullName: '',
      department: '',
      role: ''
    });
    setError('');
    setSuccess('');
  };

  const switchMode = () => {
    setIsLogin(!isLogin);
    resetForm();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 flex items-center justify-center p-4">
      {/* Animated Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-72 h-72 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute top-40 right-20 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-2000"></div>
        <div className="absolute -bottom-8 left-40 w-72 h-72 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-4000"></div>
      </div>

      <div className="relative z-10 w-full max-w-md">
        {/* Logo and Title */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center mb-6">
            <img 
              src="/ppapedia-logo.png"
              alt="PPAPedia Logo" 
              className="h-16 w-16 mr-4 object-contain"
            />
            <h1 className="text-4xl font-bold text-white">PPAPedia</h1>
          </div>
          <p className="text-blue-200 text-lg">AI Powered Quality Engineering Platform</p>
        </div>

        {/* Form Container */}
        <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 shadow-2xl">
          <div className="flex items-center justify-center mb-6">
            <div className="bg-gradient-to-r from-blue-500 to-purple-600 p-3 rounded-full">
              {isLogin ? <Shield className="w-8 h-8 text-white" /> : <UserPlus className="w-8 h-8 text-white" />}
            </div>
          </div>
          
          <h2 className="text-2xl font-bold text-white text-center mb-6">
            {isLogin ? 'Sisteme Giriş' : 'Üye Ol'}
          </h2>

          {error && (
            <div className="mb-4 p-4 bg-red-500/20 border border-red-500/30 rounded-lg flex items-center">
              <AlertCircle className="w-5 h-5 text-red-400 mr-2" />
              <span className="text-red-200 text-sm">{error}</span>
            </div>
          )}

          {success && (
            <div className="mb-4 p-4 bg-green-500/20 border border-green-500/30 rounded-lg flex items-center">
              <Shield className="w-5 h-5 text-green-400 mr-2" />
              <span className="text-green-200 text-sm">{success}</span>
            </div>
          )}

          <form onSubmit={isLogin ? handleLogin : handleRegister} className="space-y-4">
            {/* Full Name - Sadece üye ol formunda */}
            {!isLogin && (
              <div>
                <label htmlFor="fullName" className="block text-sm font-medium text-white mb-2">
                  Ad Soyad *
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <input
                    type="text"
                    id="fullName"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent backdrop-blur-sm"
                    placeholder="Adınız ve soyadınız"
                    disabled={isLoading}
                  />
                </div>
              </div>
            )}

            {/* Email - Sadece üye ol formunda */}
            {!isLogin && (
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-white mb-2">
                  Email *
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent backdrop-blur-sm"
                    placeholder="email@sirket.com"
                    disabled={isLoading}
                  />
                </div>
              </div>
            )}

            {/* Username Field */}
            <div>
              <label htmlFor="username" className="block text-sm font-medium text-white mb-2">
                Kullanıcı Adı *
              </label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  id="username"
                  name="username"
                  value={formData.username}
                  onChange={handleInputChange}
                  className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent backdrop-blur-sm"
                  placeholder="Kullanıcı adınızı girin"
                  disabled={isLoading}
                />
              </div>
            </div>

            {/* Password Field */}
            <div>
              <label htmlFor="password" className="block text-sm font-medium text-white mb-2">
                Şifre *
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  id="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className="w-full pl-10 pr-12 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent backdrop-blur-sm"
                  placeholder={isLogin ? "Şifrenizi girin" : "En az 6 karakter"}
                  disabled={isLoading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-gray-400 hover:text-white transition-colors duration-200"
                  disabled={isLoading}
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            {/* Department - Sadece üye ol formunda */}
            {!isLogin && (
              <div>
                <label htmlFor="department" className="block text-sm font-medium text-white mb-2">
                  Departman
                </label>
                <div className="relative">
                  <Building className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <select
                    id="department"
                    name="department"
                    value={formData.department}
                    onChange={handleInputChange}
                    className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent backdrop-blur-sm appearance-none"
                    disabled={isLoading}
                  >
                    <option value="" className="bg-gray-800">Departman seçin</option>
                    <option value="Mühendislik" className="bg-gray-800">Mühendislik</option>
                    <option value="Üretim" className="bg-gray-800">Üretim</option>
                    <option value="Kalite" className="bg-gray-800">Kalite</option>
                    <option value="Bakım" className="bg-gray-800">Bakım</option>
                    <option value="İnsan Kaynakları" className="bg-gray-800">İnsan Kaynakları</option>
                    <option value="IT" className="bg-gray-800">IT</option>
                  </select>
                </div>
              </div>
            )}

            {/* Role - Sadece üye ol formunda */}
            {!isLogin && (
              <div>
                <label htmlFor="role" className="block text-sm font-medium text-white mb-2">
                  Pozisyon
                </label>
                <div className="relative">
                  <Shield className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <input
                    type="text"
                    id="role"
                    name="role"
                    value={formData.role}
                    onChange={handleInputChange}
                    className="w-full pl-10 pr-4 py-3 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-transparent backdrop-blur-sm"
                    placeholder="Mühendis, Teknisyen, Sorumlu vb."
                    disabled={isLoading}
                  />
                </div>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 px-4 rounded-lg hover:from-blue-700 hover:to-purple-700 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center font-semibold mt-6"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  {isLogin ? 'Giriş Yapılıyor...' : 'Üyelik Oluşturuluyor...'}
                </>
              ) : (
                <>
                  {isLogin ? <Shield className="w-5 h-5 mr-2" /> : <UserPlus className="w-5 h-5 mr-2" />}
                  {isLogin ? 'Giriş Yap' : 'Üye Ol'}
                </>
              )}
            </button>
          </form>

          {/* Switch Mode */}
          <div className="mt-6 text-center">
            <button
              onClick={switchMode}
              className="text-blue-300 hover:text-white transition-colors duration-200 text-sm"
              disabled={isLoading}
            >
              {isLogin ? (
                <>Hesabınız yok mu? <span className="font-semibold">Üye Ol</span></>
              ) : (
                <>Zaten hesabınız var mı? <span className="font-semibold">Giriş Yap</span></>
              )}
            </button>
          </div>

          {/* Demo Accounts Info - Sadece giriş formunda */}
          {isLogin && (
            <div className="mt-8 p-4 bg-blue-500/20 border border-blue-500/30 rounded-lg">
              <h3 className="text-white font-semibold mb-2 text-sm">Demo Hesapları:</h3>
              <div className="space-y-1 text-xs text-blue-200">
                <div>• <strong>admin</strong> / admin123 (Yönetici)</div>
                <div>• <strong>ahmet.yilmaz</strong> / kalip2025 (Kalıp Müh.)</div>
                <div>• <strong>fatma.demir</strong> / kalite2025 (Kalite Müh.)</div>
                <div>• <strong>mehmet.kaya</strong> / bakim2025 (Bakım Tek.)</div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-blue-300 text-sm">
            © 2025 PPAPedia - {isLogin ? 'Güvenli Giriş Sistemi' : 'Üyelik Sistemi'}
          </p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
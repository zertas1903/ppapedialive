import React from 'react';
import { TrendingUp, CheckCircle, Clock, AlertTriangle, Users, Calendar, Target, Award } from 'lucide-react';

const WorkDashboard: React.FC = () => {
  const stats = [
    { 
      title: 'Toplam Görev', 
      value: '47', 
      change: '+5 bu hafta', 
      changeType: 'increase' as const,
      icon: Target,
      color: 'blue'
    },
    { 
      title: 'Tamamlanan', 
      value: '32', 
      change: '+8 bu hafta', 
      changeType: 'increase' as const,
      icon: CheckCircle,
      color: 'green'
    },
    { 
      title: 'Devam Eden', 
      value: '12', 
      change: '-2 bu hafta', 
      changeType: 'decrease' as const,
      icon: Clock,
      color: 'yellow'
    },
    { 
      title: 'Geciken', 
      value: '3', 
      change: '-1 bu hafta', 
      changeType: 'decrease' as const,
      icon: AlertTriangle,
      color: 'red'
    }
  ];

  const teamPerformance = [
    { name: 'Ahmet Yılmaz', completed: 12, inProgress: 3, efficiency: 94 },
    { name: 'Mehmet Kaya', completed: 8, inProgress: 2, efficiency: 87 },
    { name: 'Fatma Demir', completed: 15, inProgress: 4, efficiency: 96 },
    { name: 'Ali Özkan', completed: 6, inProgress: 1, efficiency: 82 },
    { name: 'Zeynep Arslan', completed: 11, inProgress: 2, efficiency: 91 }
  ];

  const recentActivities = [
    {
      id: 1,
      action: 'Görev Tamamlandı',
      task: 'Operatör Eğitim Programı',
      user: 'Ali Özkan',
      time: '2 saat önce',
      type: 'completed'
    },
    {
      id: 2,
      action: 'Yeni Görev Eklendi',
      task: 'Kalıp Bakım Kontrolü',
      user: 'Ahmet Yılmaz',
      time: '4 saat önce',
      type: 'created'
    },
    {
      id: 3,
      action: 'Görev Güncellendi',
      task: 'IP Renk Tutarlılığı Kontrolü',
      user: 'Zeynep Arslan',
      time: '6 saat önce',
      type: 'updated'
    },
    {
      id: 4,
      action: 'Termin Uzatıldı',
      task: 'Boya Kabini Filtre Değişimi',
      user: 'Mehmet Kaya',
      time: '1 gün önce',
      type: 'extended'
    }
  ];

  const getColorClasses = (color: string) => {
    const colorMap: Record<string, { bg: string; text: string; border: string }> = {
      blue: { bg: 'bg-blue-500', text: 'text-blue-600', border: 'border-blue-200' },
      green: { bg: 'bg-green-500', text: 'text-green-600', border: 'border-green-200' },
      yellow: { bg: 'bg-yellow-500', text: 'text-yellow-600', border: 'border-yellow-200' },
      red: { bg: 'bg-red-500', text: 'text-red-600', border: 'border-red-200' }
    };
    return colorMap[color] || colorMap.blue;
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'created':
        return <Target className="w-4 h-4 text-blue-500" />;
      case 'updated':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'extended':
        return <Calendar className="w-4 h-4 text-orange-500" />;
      default:
        return <Target className="w-4 h-4 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">İş Takip Dashboard</h2>
        <p className="text-gray-600 mt-1">Ekip performansı ve proje durumlarının genel görünümü</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          const colors = getColorClasses(stat.color);
          
          return (
            <div key={index} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div className={`p-3 rounded-lg ${colors.bg}`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <span className={`text-sm font-medium ${
                  stat.changeType === 'increase' 
                    ? 'text-green-600'
                    : 'text-red-600'
                }`}>
                  {stat.change}
                </span>
              </div>
              
              <div className="mt-4">
                <h3 className="text-2xl font-bold text-gray-900">{stat.value}</h3>
                <p className="text-gray-600 text-sm mt-1">{stat.title}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* Team Performance and Recent Activities */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Team Performance */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center">
              <Users className="w-5 h-5 text-blue-600 mr-2" />
              <h3 className="text-lg font-semibold text-gray-900">Ekip Performansı</h3>
            </div>
          </div>
          
          <div className="p-6">
            <div className="space-y-4">
              {teamPerformance.map((member, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900">{member.name}</h4>
                    <p className="text-sm text-gray-600 mt-1">
                      {member.completed} tamamlandı • {member.inProgress} devam ediyor
                    </p>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <div className="text-sm font-medium text-gray-900">{member.efficiency}%</div>
                      <div className="text-xs text-gray-500">Verimlilik</div>
                    </div>
                    
                    <div className="w-16 h-2 bg-gray-200 rounded-full">
                      <div 
                        className={`h-2 rounded-full transition-all duration-300 ${
                          member.efficiency >= 90 ? 'bg-gradient-to-r from-green-400 to-green-600' :
                          member.efficiency >= 80 ? 'bg-gradient-to-r from-yellow-400 to-green-500' :
                          member.efficiency >= 70 ? 'bg-gradient-to-r from-orange-400 to-yellow-500' :
                          'bg-gradient-to-r from-red-400 to-orange-500'
                        }`}
                        style={{ width: `${member.efficiency}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Recent Activities */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center">
              <Award className="w-5 h-5 text-purple-600 mr-2" />
              <h3 className="text-lg font-semibold text-gray-900">Son Aktiviteler</h3>
            </div>
          </div>
          
          <div className="p-6">
            <div className="space-y-4">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-start space-x-3">
                  <div className="flex-shrink-0 mt-1">
                    {getActivityIcon(activity.type)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-gray-900">
                      <span className="font-medium">{activity.action}</span>
                    </p>
                    <p className="text-sm text-gray-600 mt-1">
                      {activity.task} • {activity.user}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Weekly Progress Chart */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-6">Haftalık İlerleme</h3>
        
        <div className="grid grid-cols-7 gap-4">
          {['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'].map((day, index) => {
            const completed = [8, 12, 6, 15, 9, 4, 2][index];
            const maxHeight = 15;
            const height = (completed / maxHeight) * 100;
            
            return (
              <div key={day} className="text-center">
                <div className="h-32 flex items-end justify-center mb-2">
                  <div 
                    className="w-8 bg-gradient-to-t from-blue-500 to-cyan-400 rounded-t-lg transition-all duration-300 hover:from-blue-600 hover:to-cyan-500"
                    style={{ height: `${height}%` }}
                  ></div>
                </div>
                <div className="text-xs text-gray-600 mb-1">{day}</div>
                <div className="text-sm font-medium text-gray-900">{completed}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default WorkDashboard;

import React, { useState } from 'react';
import { User, LogOut, Settings, Shield, Clock, Award } from 'lucide-react';

interface UserProfileProps {
  username: string;
  onLogout: () => void;
}

const UserProfile: React.FC<UserProfileProps> = ({ username, onLogout }) => {
  const [showProfile, setShowProfile] = useState(false);

  // Kullanıcı bilgilerini localStorage'dan al
  const userInfo = JSON.parse(localStorage.getItem('ppapedia_user') || '{}');
  
  const handleLogout = () => {
    localStorage.removeItem('ppapedia_user');
    onLogout();
  };

  const getInitials = (name: string) => {
    return name.split('.').map(part => part.charAt(0).toUpperCase()).join('');
  };

  const formatLoginTime = (loginTime: string) => {
    if (!loginTime) return 'Bilinmiyor';
    const date = new Date(loginTime);
    return date.toLocaleString('tr-TR');
  };

  return (
    <div className="relative">
      <button
        onClick={() => setShowProfile(!showProfile)}
        className="flex items-center space-x-3 bg-white rounded-lg shadow-sm border border-gray-200 px-4 py-2 hover:bg-gray-50 transition-colors duration-200"
      >
        <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold text-sm">
          {getInitials(username)}
        </div>
        <div className="text-left">
          <div className="text-sm font-medium text-gray-900">{username}</div>
          <div className="text-xs text-gray-500">{userInfo.role || 'Kullanıcı'}</div>
        </div>
      </button>

      {showProfile && (
        <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-xl border border-gray-200 z-50">
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
                {getInitials(username)}
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{username}</h3>
                <p className="text-sm text-gray-600">{userInfo.role || 'Kullanıcı'}</p>
                <div className="flex items-center mt-1">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                  <span className="text-xs text-green-600">Aktif</span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-4">
            <div className="space-y-3">
              <div className="flex items-center text-sm text-gray-600">
                <Clock className="w-4 h-4 mr-3" />
                <div>
                  <div className="font-medium">Son Giriş</div>
                  <div className="text-xs">{formatLoginTime(userInfo.loginTime)}</div>
                </div>
              </div>

              <div className="flex items-center text-sm text-gray-600">
                <Shield className="w-4 h-4 mr-3" />
                <div>
                  <div className="font-medium">Yetki Seviyesi</div>
                  <div className="text-xs">{userInfo.role || 'Standart Kullanıcı'}</div>
                </div>
              </div>

              <div className="flex items-center text-sm text-gray-600">
                <Award className="w-4 h-4 mr-3" />
                <div>
                  <div className="font-medium">Durum</div>
                  <div className="text-xs text-green-600">Aktif Kullanıcı</div>
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 border-t border-gray-200">
            <div className="space-y-2">
              <button className="w-full flex items-center px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg transition-colors duration-200">
                <Settings className="w-4 h-4 mr-3" />
                Hesap Ayarları
              </button>
              
              <button
                onClick={handleLogout}
                className="w-full flex items-center px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors duration-200"
              >
                <LogOut className="w-4 h-4 mr-3" />
                Çıkış Yap
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserProfile;
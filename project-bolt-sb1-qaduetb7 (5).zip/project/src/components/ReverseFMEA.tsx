import React, { useState } from 'react';
import { Upload, Download, Brain, FileSpreadsheet, AlertTriangle, CheckCircle, Target, Zap, FileText, BarChart3, Settings, Plus, Trash2 } from 'lucide-react';

interface FMEAData {
  processStep: string;
  potentialFailure: string;
  effects: string;
  severity: number;
  causes: string;
  occurrence: number;
  controls: string;
  detection: number;
  rpn: number;
}

interface ReverseFMEAItem {
  id: string;
  originalFailure: string;
  preventiveAction: string;
  monitoringMethod: string;
  responsibility: string;
  timeline: string;
  successCriteria: string;
  priority: 'high' | 'medium' | 'low';
}

const ReverseFMEA: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'upload' | 'create' | 'analyze'>('upload');
  const [manualFMEA, setManualFMEA] = useState({
    processSteps: [
      {
        id: 1,
        processStep: '',
        potentialFailure: '',
        effects: '',
        severity: 5,
        causes: '',
        occurrence: 5,
        controls: '',
        detection: 5,
        rpn: 125
      }
    ]
  });
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [fmeaData, setFmeaData] = useState<FMEAData[]>([]);
  const [reverseFmeaItems, setReverseFmeaItems] = useState<ReverseFMEAItem[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisComplete, setAnalysisComplete] = useState(false);

  const addManualFMEARow = () => {
    const newRow = {
      id: manualFMEA.processSteps.length + 1,
      processStep: '',
      potentialFailure: '',
      effects: '',
      severity: 5,
      causes: '',
      occurrence: 5,
      controls: '',
      detection: 5,
      rpn: 125
    };
    setManualFMEA(prev => ({
      ...prev,
      processSteps: [...prev.processSteps, newRow]
    }));
  };

  const updateManualFMEARow = (id: number, field: string, value: any) => {
    setManualFMEA(prev => ({
      ...prev,
      processSteps: prev.processSteps.map(step => {
        if (step.id === id) {
          const updatedStep = { ...step, [field]: value };
          // RPN hesaplama
          if (['severity', 'occurrence', 'detection'].includes(field)) {
            updatedStep.rpn = updatedStep.severity * updatedStep.occurrence * updatedStep.detection;
          }
          return updatedStep;
        }
        return step;
      })
    }));
  };

  const removeManualFMEARow = (id: number) => {
    if (manualFMEA.processSteps.length > 1) {
      setManualFMEA(prev => ({
        ...prev,
        processSteps: prev.processSteps.filter(step => step.id !== id)
      }));
    }
  };

  const processManualFMEA = () => {
    const validSteps = manualFMEA.processSteps.filter(step => 
      step.processStep.trim() && step.potentialFailure.trim()
    );
    
    if (validSteps.length === 0) {
      alert('Lütfen en az bir FMEA kaydı doldurun!');
      return;
    }

    const fmeaData = validSteps.map(step => ({
      processStep: step.processStep,
      potentialFailure: step.potentialFailure,
      effects: step.effects,
      severity: step.severity,
      causes: step.causes,
      occurrence: step.occurrence,
      controls: step.controls,
      detection: step.detection,
      rpn: step.rpn
    }));

    setFmeaData(fmeaData);
    setIsAnalyzing(true);
    setActiveTab('analyze');
    
    setTimeout(() => {
      setIsAnalyzing(false);
      generateReverseFMEA(fmeaData);
    }, 3000);
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadedFile(file);
      // Simulate file parsing
      simulateFileAnalysis(file);
    }
  };

  const simulateFileAnalysis = (file: File) => {
    setIsAnalyzing(true);
    
    // Simulate FMEA data extraction
    setTimeout(() => {
      const mockFmeaData: FMEAData[] = [
        {
          processStep: 'Plastik Enjeksiyon',
          potentialFailure: 'Eksik Baskı',
          effects: 'Ürün spesifikasyona uygun değil',
          severity: 8,
          causes: 'Düşük enjeksiyon basıncı, kalıp havalandırma yetersizliği',
          occurrence: 6,
          controls: 'Basınç kontrol sistemi',
          detection: 4,
          rpn: 192
        },
        {
          processStep: 'Boyama İşlemi',
          potentialFailure: 'Renk Tutarsızlığı',
          effects: 'Görsel kalite problemi',
          severity: 6,
          causes: 'Boya karışım oranı hatalı, sprey tabancası ayarı',
          occurrence: 4,
          controls: 'Renk kontrol kartları',
          detection: 3,
          rpn: 72
        },
        {
          processStep: 'Montaj',
          potentialFailure: 'Yanlış Parça Takılması',
          effects: 'Fonksiyon kaybı',
          severity: 9,
          causes: 'Operatör hatası, parça benzerliği',
          occurrence: 3,
          controls: 'Görsel kontrol',
          detection: 5,
          rpn: 135
        }
      ];
      
      setFmeaData(mockFmeaData);
      setIsAnalyzing(false);
      generateReverseFMEA(mockFmeaData);
    }, 3000);
  };

  const generateReverseFMEA = (data: FMEAData[]) => {
    const reverseFmeaItems: ReverseFMEAItem[] = data.map((item, index) => ({
      id: `rfmea-${index + 1}`,
      originalFailure: item.potentialFailure,
      preventiveAction: generatePreventiveAction(item),
      monitoringMethod: generateMonitoringMethod(item),
      responsibility: getResponsibility(item.processStep),
      timeline: getTimeline(item.rpn),
      successCriteria: generateSuccessCriteria(item),
      priority: getPriority(item.rpn)
    }));
    
    setReverseFmeaItems(reverseFmeaItems);
    setAnalysisComplete(true);
  };

  const generatePreventiveAction = (item: FMEAData): string => {
    const actions: Record<string, string> = {
      'Eksik Baskı': 'Enjeksiyon parametrelerinin optimizasyonu, kalıp havalandırma sisteminin iyileştirilmesi',
      'Renk Tutarsızlığı': 'Otomatik boya karışım sistemi kurulumu, operatör eğitim programı',
      'Yanlış Parça Takılması': 'Poka-yoke sistemi kurulumu, parça kodlama sistemi'
    };
    return actions[item.potentialFailure] || 'Kök neden analizine dayalı düzeltici eylem planı';
  };

  const generateMonitoringMethod = (item: FMEAData): string => {
    const methods: Record<string, string> = {
      'Eksik Baskı': 'Gerçek zamanlı basınç monitörü, günlük kalıp kontrol listesi',
      'Renk Tutarsızlığı': 'Spektrofotometre ile renk ölçümü, saatlik görsel kontrol',
      'Yanlış Parça Takılması': 'Barkod okuma sistemi, çift kontrol prosedürü'
    };
    return methods[item.potentialFailure] || 'İstatistiksel proses kontrol grafikları';
  };

  const getResponsibility = (processStep: string): string => {
    const responsibilities: Record<string, string> = {
      'Plastik Enjeksiyon': 'Proses Mühendisi',
      'Boyama İşlemi': 'Kalite Kontrol Sorumlusu',
      'Montaj': 'Üretim Sorumlusu'
    };
    return responsibilities[processStep] || 'Süreç Sorumlusu';
  };

  const getTimeline = (rpn: number): string => {
    if (rpn >= 150) return '1 hafta';
    if (rpn >= 100) return '2 hafta';
    if (rpn >= 50) return '1 ay';
    return '3 ay';
  };

  const generateSuccessCriteria = (item: FMEAData): string => {
    return `RPN değerinin ${Math.floor(item.rpn * 0.3)} altına düşürülmesi, ${item.effects} oranının %90 azaltılması`;
  };

  const getPriority = (rpn: number): 'high' | 'medium' | 'low' => {
    if (rpn >= 150) return 'high';
    if (rpn >= 100) return 'medium';
    return 'low';
  };

  const exportToExcel = () => {
    let csvContent = "Reverse FMEA Raporu\n\n";
    csvContent += "Orijinal Hata,Önleyici Eylem,İzleme Yöntemi,Sorumlu,Zaman Çizelgesi,Başarı Kriterleri,Öncelik\n";
    
    reverseFmeaItems.forEach(item => {
      csvContent += `"${item.originalFailure}","${item.preventiveAction}","${item.monitoringMethod}","${item.responsibility}","${item.timeline}","${item.successCriteria}","${item.priority}"\n`;
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `Reverse_FMEA_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getPriorityColor = (priority: string) => {
    const colorMap: Record<string, string> = {
      high: 'bg-red-100 text-red-800 border-red-200',
      medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      low: 'bg-green-100 text-green-800 border-green-200'
    };
    return colorMap[priority] || colorMap.medium;
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high':
        return <AlertTriangle className="w-4 h-4" />;
      case 'medium':
        return <Target className="w-4 h-4" />;
      case 'low':
        return <CheckCircle className="w-4 h-4" />;
      default:
        return <Target className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Reverse FMEA</h2>
        <p className="text-gray-600 mt-1">FMEA analizinden önleyici eylem planı oluşturun</p>
      </div>

      {/* Tab Navigation */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="flex border-b border-gray-200">
          <button
            onClick={() => setActiveTab('upload')}
            className={`flex-1 px-6 py-4 text-center font-medium transition-colors duration-200 ${
              activeTab === 'upload'
                ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-500'
                : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
            }`}
          >
            <Upload className="w-5 h-5 mx-auto mb-1" />
            FMEA Yükle
          </button>
          <button
            onClick={() => setActiveTab('analyze')}
            className={`flex-1 px-6 py-4 text-center font-medium transition-colors duration-200 ${
              activeTab === 'analyze'
                ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-500'
                : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
            }`}
          >
            <Brain className="w-5 h-5 mx-auto mb-1" />
            AI Analizi
          </button>
          <button
            onClick={() => setActiveTab('create')}
            className={`flex-1 px-6 py-4 text-center font-medium transition-colors duration-200 ${
              activeTab === 'create'
                ? 'bg-blue-50 text-blue-600 border-b-2 border-blue-500'
                : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
            }`}
          >
            <FileSpreadsheet className="w-5 h-5 mx-auto mb-1" />
            Reverse FMEA
          </button>
        </div>

        <div className="p-6">
          {activeTab === 'upload' && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="bg-blue-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Upload className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">FMEA Dosyası Yükleyin</h3>
                <p className="text-gray-600 mb-6">
                  Excel (.xlsx, .xls) veya CSV formatında FMEA dosyanızı yükleyin
                </p>
              </div>

              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-400 transition-colors duration-200">
                <input
                  type="file"
                  accept=".xlsx,.xls,.csv"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="fmea-upload"
                />
                <label
                  htmlFor="fmea-upload"
                  className="cursor-pointer flex flex-col items-center"
                >
                  <FileText className="w-12 h-12 text-gray-400 mb-4" />
                  <span className="text-lg font-medium text-gray-700 mb-2">
                    Dosya seçmek için tıklayın
                  </span>
                  <span className="text-sm text-gray-500">
                    veya dosyayı buraya sürükleyin
                  </span>
                </label>
              </div>

              {uploadedFile && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                    <div>
                      <p className="font-medium text-green-800">Dosya Yüklendi</p>
                      <p className="text-sm text-green-600">{uploadedFile.name}</p>
                    </div>
                  </div>
                </div>
              )}

              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h4 className="text-lg font-semibold text-blue-900 mb-4">FMEA Dosya Formatı</h4>
                <div className="text-sm text-blue-800 space-y-2">
                  <p><strong>Gerekli Sütunlar:</strong></p>
                  <ul className="list-disc list-inside space-y-1 ml-4">
                    <li>Süreç Adımı / Process Step</li>
                    <li>Potansiyel Hata / Potential Failure</li>
                    <li>Hata Etkileri / Effects</li>
                    <li>Şiddet / Severity (1-10)</li>
                    <li>Hata Nedenleri / Causes</li>
                    <li>Oluşma / Occurrence (1-10)</li>
                    <li>Mevcut Kontroller / Current Controls</li>
                    <li>Tespit / Detection (1-10)</li>
                    <li>RPN (Risk Priority Number)</li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'create' && (
            <div className="space-y-6">
              <div className="text-center mb-6">
                <div className="bg-purple-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  <Brain className="w-8 h-8 text-purple-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Manuel FMEA Oluştur</h3>
                <p className="text-gray-600">
                  FMEA analizinizi manuel olarak oluşturun ve AI ile Reverse FMEA'ya dönüştürün
                </p>
              </div>

              <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                <div className="px-6 py-4 bg-gray-50 border-b border-gray-200 flex items-center justify-between">
                  <h4 className="text-lg font-semibold text-gray-900">FMEA Tablosu</h4>
                  <button
                    onClick={addManualFMEARow}
                    className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Satır Ekle
                  </button>
                </div>
                
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Süreç Adımı</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Potansiyel Hata</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Etki</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Şiddet</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Neden</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Oluşma</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kontrol</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tespit</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">RPN</th>
                        <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">İşlem</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {manualFMEA.processSteps.map((step) => (
                        <tr key={step.id} className="hover:bg-gray-50">
                          <td className="px-4 py-3">
                            <input
                              type="text"
                              value={step.processStep}
                              onChange={(e) => updateManualFMEARow(step.id, 'processStep', e.target.value)}
                              className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                              placeholder="Süreç adımı"
                            />
                          </td>
                          <td className="px-4 py-3">
                            <input
                              type="text"
                              value={step.potentialFailure}
                              onChange={(e) => updateManualFMEARow(step.id, 'potentialFailure', e.target.value)}
                              className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                              placeholder="Potansiyel hata"
                            />
                          </td>
                          <td className="px-4 py-3">
                            <input
                              type="text"
                              value={step.effects}
                              onChange={(e) => updateManualFMEARow(step.id, 'effects', e.target.value)}
                              className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                              placeholder="Etki"
                            />
                          </td>
                          <td className="px-4 py-3">
                            <select
                              value={step.severity}
                              onChange={(e) => updateManualFMEARow(step.id, 'severity', parseInt(e.target.value))}
                              className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                            >
                              {[1,2,3,4,5,6,7,8,9,10].map(num => (
                                <option key={num} value={num}>{num}</option>
                              ))}
                            </select>
                          </td>
                          <td className="px-4 py-3">
                            <input
                              type="text"
                              value={step.causes}
                              onChange={(e) => updateManualFMEARow(step.id, 'causes', e.target.value)}
                              className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                              placeholder="Neden"
                            />
                          </td>
                          <td className="px-4 py-3">
                            <select
                              value={step.occurrence}
                              onChange={(e) => updateManualFMEARow(step.id, 'occurrence', parseInt(e.target.value))}
                              className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                            >
                              {[1,2,3,4,5,6,7,8,9,10].map(num => (
                                <option key={num} value={num}>{num}</option>
                              ))}
                            </select>
                          </td>
                          <td className="px-4 py-3">
                            <input
                              type="text"
                              value={step.controls}
                              onChange={(e) => updateManualFMEARow(step.id, 'controls', e.target.value)}
                              className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                              placeholder="Kontrol"
                            />
                          </td>
                          <td className="px-4 py-3">
                            <select
                              value={step.detection}
                              onChange={(e) => updateManualFMEARow(step.id, 'detection', parseInt(e.target.value))}
                              className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                            >
                              {[1,2,3,4,5,6,7,8,9,10].map(num => (
                                <option key={num} value={num}>{num}</option>
                              ))}
                            </select>
                          </td>
                          <td className="px-4 py-3">
                            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              step.rpn >= 150 ? 'bg-red-100 text-red-800' :
                              step.rpn >= 100 ? 'bg-yellow-100 text-yellow-800' :
                              'bg-green-100 text-green-800'
                            }`}>
                              {step.rpn}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <button
                              onClick={() => removeManualFMEARow(step.id)}
                              disabled={manualFMEA.processSteps.length === 1}
                              className="text-red-600 hover:text-red-800 disabled:text-gray-400 disabled:cursor-not-allowed"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="flex justify-center">
                <button
                  onClick={processManualFMEA}
                  className="flex items-center px-8 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors duration-200"
                >
                  <Brain className="w-5 h-5 mr-2" />
                  AI ile Reverse FMEA Oluştur
                </button>
              </div>
            </div>
          )}

          {activeTab === 'analyze' && (
            <div className="space-y-6">
              {isAnalyzing ? (
                <div className="text-center py-12">
                  <div className="bg-purple-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <Brain className="w-8 h-8 text-purple-600 animate-pulse" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">AI Analizi Devam Ediyor</h3>
                  <p className="text-gray-600 mb-6">FMEA verileriniz yapay zeka tarafından analiz ediliyor...</p>
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mx-auto"></div>
                </div>
              ) : fmeaData.length > 0 ? (
                <div className="space-y-6">
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <div className="flex items-center">
                      <CheckCircle className="w-5 h-5 text-green-600 mr-3" />
                      <div>
                        <p className="font-medium text-green-800">Analiz Tamamlandı</p>
                        <p className="text-sm text-green-600">{fmeaData.length} FMEA kaydı analiz edildi</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
                    <div className="px-6 py-4 bg-gray-50 border-b border-gray-200">
                      <h4 className="text-lg font-semibold text-gray-900">Analiz Edilen FMEA Verileri</h4>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Süreç</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Hata</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Etki</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">RPN</th>
                          </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                          {fmeaData.map((item, index) => (
                            <tr key={index} className="hover:bg-gray-50">
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                {item.processStep}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {item.potentialFailure}
                              </td>
                              <td className="px-6 py-4 text-sm text-gray-900">
                                {item.effects}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                  item.rpn >= 150 ? 'bg-red-100 text-red-800' :
                                  item.rpn >= 100 ? 'bg-yellow-100 text-yellow-800' :
                                  'bg-green-100 text-green-800'
                                }`}>
                                  {item.rpn}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="bg-gray-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <Brain className="w-8 h-8 text-gray-400" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Analiz Bekliyor</h3>
                  <p className="text-gray-600">Önce bir FMEA dosyası yükleyin veya manuel FMEA oluşturun</p>
                </div>
              )}
            </div>
          )}

          {/* Reverse FMEA Results - Show when analysis is complete */}
          {analysisComplete && (
            <div className="mt-8 space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">Reverse FMEA Planı</h3>
                  <p className="text-gray-600">AI tarafından oluşturulan önleyici eylem planı</p>
                </div>
                <button
                  onClick={exportToExcel}
                  className="flex items-center px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Excel'e Aktar
                </button>
              </div>

              <div className="grid grid-cols-1 gap-6">
                {reverseFmeaItems.map((item) => (
                  <div key={item.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow duration-200">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h4 className="text-lg font-semibold text-gray-900 mb-2">
                          {item.originalFailure}
                        </h4>
                        <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium border ${getPriorityColor(item.priority)}`}>
                          {getPriorityIcon(item.priority)}
                          <span className="ml-1 capitalize">{item.priority} Öncelik</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-gray-600">Hedef Süre</div>
                        <div className="font-semibold text-gray-900">{item.timeline}</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h5 className="font-medium text-gray-900 mb-2 flex items-center">
                          <Target className="w-4 h-4 mr-2 text-blue-600" />
                          Önleyici Eylem
                        </h5>
                        <p className="text-sm text-gray-700 bg-blue-50 p-3 rounded-lg">
                          {item.preventiveAction}
                        </p>
                      </div>

                      <div>
                        <h5 className="font-medium text-gray-900 mb-2 flex items-center">
                          <BarChart3 className="w-4 h-4 mr-2 text-green-600" />
                          İzleme Yöntemi
                        </h5>
                        <p className="text-sm text-gray-700 bg-green-50 p-3 rounded-lg">
                          {item.monitoringMethod}
                        </p>
                      </div>

                      <div>
                        <h5 className="font-medium text-gray-900 mb-2 flex items-center">
                          <Settings className="w-4 h-4 mr-2 text-purple-600" />
                          Sorumlu
                        </h5>
                        <p className="text-sm text-gray-700 bg-purple-50 p-3 rounded-lg">
                          {item.responsibility}
                        </p>
                      </div>

                      <div>
                        <h5 className="font-medium text-gray-900 mb-2 flex items-center">
                          <CheckCircle className="w-4 h-4 mr-2 text-orange-600" />
                          Başarı Kriterleri
                        </h5>
                        <p className="text-sm text-gray-700 bg-orange-50 p-3 rounded-lg">
                          {item.successCriteria}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ReverseFMEA;
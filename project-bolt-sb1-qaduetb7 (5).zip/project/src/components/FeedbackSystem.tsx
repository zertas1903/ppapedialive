import React, { useState } from 'react';
import { X, Send, Heart, MessageCircle, User, Clock } from 'lucide-react';

interface Feedback {
  id: number;
  user: string;
  message: string;
  timestamp: Date;
  likes: number;
  liked: boolean;
}

interface FeedbackSystemProps {
  onClose: () => void;
}

const FeedbackSystem: React.FC<FeedbackSystemProps> = ({ onClose }) => {
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([
    {
      id: 1,
      user: 'A.Y',
      message: 'Kalıp mühendisliği için daha detaylı analiz seçenekleri olabilir. Özellikle sıcaklık profili analizi çok faydalı olurdu.',
      timestamp: new Date(Date.now() - 1000 * 60 * 30),
      likes: 5,
      liked: false
    },
    {
      id: 2,
      user: 'M.K',
      message: 'Mobil uygulama versiyonu olsa harika olur. Sahada çalışırken çok işime yarayacak.',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2),
      likes: 8,
      liked: true
    },
    {
      id: 3,
      user: 'F.D',
      message: 'Excel entegrasyonu mükemmel! Belki PowerBI entegrasyonu da eklenebilir.',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 4),
      likes: 3,
      liked: false
    },
    {
      id: 4,
      user: 'Z.A',
      message: 'AI analizleri çok başarılı. Türkçe dil desteği de çok iyi. Teşekkürler!',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 6),
      likes: 12,
      liked: false
    }
  ]);

  const [newMessage, setNewMessage] = useState('');
  const [userName, setUserName] = useState('');

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) {
      return `${diffInMinutes} dakika önce`;
    } else if (diffInMinutes < 1440) {
      return `${Math.floor(diffInMinutes / 60)} saat önce`;
    } else {
      return `${Math.floor(diffInMinutes / 1440)} gün önce`;
    }
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(word => word.charAt(0).toUpperCase()).join('.');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newMessage.trim() || !userName.trim()) {
      alert('Lütfen isim ve mesaj alanlarını doldurun!');
      return;
    }

    const newFeedback: Feedback = {
      id: Date.now(),
      user: getInitials(userName),
      message: newMessage.trim(),
      timestamp: new Date(),
      likes: 0,
      liked: false
    };

    setFeedbacks(prev => [newFeedback, ...prev]);
    setNewMessage('');
    setUserName('');
  };

  const handleLike = (id: number) => {
    setFeedbacks(prev => prev.map(feedback => {
      if (feedback.id === id) {
        return {
          ...feedback,
          likes: feedback.liked ? feedback.likes - 1 : feedback.likes + 1,
          liked: !feedback.liked
        };
      }
      return feedback;
    }));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-orange-500 to-red-500 text-white p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <MessageCircle className="w-6 h-6 mr-3" />
              <div>
                <h3 className="text-xl font-bold">Beni Geliştir</h3>
                <p className="text-orange-100 text-sm">Önerileriniz değerli!</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/20 rounded-lg transition-colors duration-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex flex-col h-[60vh]">
          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {feedbacks.map((feedback) => (
              <div key={feedback.id} className="bg-gray-50 rounded-lg p-4 hover:bg-gray-100 transition-colors duration-200">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-sm font-semibold">
                      {feedback.user}
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">{feedback.user}</div>
                      <div className="flex items-center text-xs text-gray-500">
                        <Clock className="w-3 h-3 mr-1" />
                        {formatTimeAgo(feedback.timestamp)}
                      </div>
                    </div>
                  </div>
                  
                  <button
                    onClick={() => handleLike(feedback.id)}
                    className={`flex items-center space-x-1 px-3 py-1 rounded-full text-sm transition-all duration-200 ${
                      feedback.liked 
                        ? 'bg-red-100 text-red-600 hover:bg-red-200' 
                        : 'bg-gray-200 text-gray-600 hover:bg-red-100 hover:text-red-600'
                    }`}
                  >
                    <Heart className={`w-4 h-4 ${feedback.liked ? 'fill-current' : ''}`} />
                    <span>{feedback.likes}</span>
                  </button>
                </div>
                
                <p className="text-gray-700 leading-relaxed">{feedback.message}</p>
              </div>
            ))}
          </div>

          {/* Input Form */}
          <div className="border-t border-gray-200 p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="Adınız Soyadınız"
                  className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                />
                <div className="flex items-center text-sm text-gray-500">
                  <User className="w-4 h-4 mr-2" />
                  Sadece baş harfler görünecek
                </div>
              </div>
              
              <div className="flex space-x-3">
                <textarea
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Geliştirme önerinizi yazın..."
                  rows={3}
                  className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                />
                <button
                  type="submit"
                  className="bg-gradient-to-r from-orange-500 to-red-500 text-white px-6 py-3 rounded-lg hover:from-orange-600 hover:to-red-600 transition-all duration-200 flex items-center justify-center"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* Stats */}
        <div className="bg-gray-50 px-6 py-4 border-t border-gray-200">
          <div className="flex items-center justify-between text-sm text-gray-600">
            <span>{feedbacks.length} öneri</span>
            <span>{feedbacks.reduce((sum, f) => sum + f.likes, 0)} toplam beğeni</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FeedbackSystem;
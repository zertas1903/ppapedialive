import React, { useState } from 'react';
import { Users, Clock, TrendingUp, AlertTriangle, Calendar, Target, User, BarChart3 } from 'lucide-react';

interface TeamMember {
  id: number;
  name: string;
  role: string;
  avatar: string;
  totalTasks: number;
  completedTasks: number;
  inProgressTasks: number;
  overdueTasks: number;
  workloadPercentage: number;
  efficiency: number;
  currentTasks: {
    title: string;
    priority: 'low' | 'medium' | 'high' | 'critical';
    dueDate: string;
    progress: number;
  }[];
}

const TeamWorkload: React.FC = () => {
  const [selectedMember, setSelectedMember] = useState<number | null>(null);

  const teamMembers: TeamMember[] = [
    {
      id: 1,
      name: 'Ahmet Yılmaz',
      role: 'Kalıp Mühendisi',
      avatar: 'AY',
      totalTasks: 15,
      completedTasks: 12,
      inProgressTasks: 3,
      overdueTasks: 0,
      workloadPercentage: 85,
      efficiency: 94,
      currentTasks: [
        { title: 'Plastik Enjeksiyon Kalıp Revizyonu', priority: 'high', dueDate: '2025-01-15', progress: 67 },
        { title: 'Kalıp Bakım Kontrolü', priority: 'medium', dueDate: '2025-01-18', progress: 30 },
        { title: 'Yeni Kalıp Tasarımı', priority: 'low', dueDate: '2025-01-25', progress: 15 }
      ]
    },
    {
      id: 2,
      name: 'Mehmet Kaya',
      role: 'Bakım Teknisyeni',
      avatar: 'MK',
      totalTasks: 10,
      completedTasks: 8,
      inProgressTasks: 2,
      overdueTasks: 0,
      workloadPercentage: 60,
      efficiency: 87,
      currentTasks: [
        { title: 'Boya Kabini Filtre Değişimi', priority: 'medium', dueDate: '2025-01-12', progress: 0 },
        { title: 'Makine Periyodik Bakımı', priority: 'high', dueDate: '2025-01-16', progress: 45 }
      ]
    },
    {
      id: 3,
      name: 'Fatma Demir',
      role: 'Kalite Mühendisi',
      avatar: 'FD',
      totalTasks: 19,
      completedTasks: 15,
      inProgressTasks: 4,
      overdueTasks: 0,
      workloadPercentage: 95,
      efficiency: 96,
      currentTasks: [
        { title: 'Kaynak Parametresi Optimizasyonu', priority: 'critical', dueDate: '2025-01-18', progress: 87 },
        { title: 'Kalite Kontrol Prosedürü', priority: 'high', dueDate: '2025-01-20', progress: 60 },
        { title: 'Müşteri Şikayet Analizi', priority: 'medium', dueDate: '2025-01-22', progress: 25 },
        { title: 'ISO Denetim Hazırlığı', priority: 'high', dueDate: '2025-01-24', progress: 40 }
      ]
    },
    {
      id: 4,
      name: 'Ali Özkan',
      role: 'Eğitim Sorumlusu',
      avatar: 'AÖ',
      totalTasks: 7,
      completedTasks: 6,
      inProgressTasks: 1,
      overdueTasks: 0,
      workloadPercentage: 40,
      efficiency: 82,
      currentTasks: [
        { title: 'Yeni Personel Oryantasyonu', priority: 'medium', dueDate: '2025-01-19', progress: 70 }
      ]
    },
    {
      id: 5,
      name: 'Zeynep Arslan',
      role: 'Proses Mühendisi',
      avatar: 'ZA',
      totalTasks: 13,
      completedTasks: 11,
      inProgressTasks: 2,
      overdueTasks: 0,
      workloadPercentage: 75,
      efficiency: 91,
      currentTasks: [
        { title: 'IP Renk Tutarlılığı Kontrolü', priority: 'high', dueDate: '2025-01-14', progress: 67 },
        { title: 'Proses Parametresi Optimizasyonu', priority: 'medium', dueDate: '2025-01-21', progress: 35 }
      ]
    }
  ];

  const getWorkloadColor = (percentage: number) => {
    if (percentage >= 90) return 'text-red-600 bg-red-100';
    if (percentage >= 70) return 'text-orange-600 bg-orange-100';
    if (percentage >= 50) return 'text-yellow-600 bg-yellow-100';
    return 'text-green-600 bg-green-100';
  };

  const getPriorityColor = (priority: string) => {
    const colorMap: Record<string, string> = {
      low: 'bg-green-100 text-green-800',
      medium: 'bg-yellow-100 text-yellow-800',
      high: 'bg-orange-100 text-orange-800',
      critical: 'bg-red-100 text-red-800'
    };
    return colorMap[priority] || colorMap.medium;
  };

  const averageWorkload = Math.round(teamMembers.reduce((sum, member) => sum + member.workloadPercentage, 0) / teamMembers.length);
  const averageEfficiency = Math.round(teamMembers.reduce((sum, member) => sum + member.efficiency, 0) / teamMembers.length);

  return (
    <div className="space-y-8">
      {/* Header */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900">Ekip Yoğunluğu</h2>
        <p className="text-gray-600 mt-1">Takım üyelerinin iş yükü ve performans analizi</p>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-lg bg-blue-500">
              <Users className="w-6 h-6 text-white" />
            </div>
            <div className="ml-4">
              <h3 className="text-2xl font-bold text-gray-900">{teamMembers.length}</h3>
              <p className="text-gray-600 text-sm">Aktif Üye</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-lg bg-orange-500">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <div className="ml-4">
              <h3 className="text-2xl font-bold text-gray-900">{averageWorkload}%</h3>
              <p className="text-gray-600 text-sm">Ortalama Yoğunluk</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-lg bg-green-500">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <div className="ml-4">
              <h3 className="text-2xl font-bold text-gray-900">{averageEfficiency}%</h3>
              <p className="text-gray-600 text-sm">Ortalama Verimlilik</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center">
            <div className="p-3 rounded-lg bg-purple-500">
              <Target className="w-6 h-6 text-white" />
            </div>
            <div className="ml-4">
              <h3 className="text-2xl font-bold text-gray-900">
                {teamMembers.reduce((sum, member) => sum + member.inProgressTasks, 0)}
              </h3>
              <p className="text-gray-600 text-sm">Devam Eden Görev</p>
            </div>
          </div>
        </div>
      </div>

      {/* Team Members Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {teamMembers.map((member) => (
          <div 
            key={member.id} 
            className="bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow duration-200 cursor-pointer"
            onClick={() => setSelectedMember(selectedMember === member.id ? null : member.id)}
          >
            <div className="p-6">
              {/* Member Header */}
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold">
                  {member.avatar}
                </div>
                <div className="ml-4 flex-1">
                  <h3 className="text-lg font-semibold text-gray-900">{member.name}</h3>
                  <p className="text-sm text-gray-600">{member.role}</p>
                </div>
                <div className={`px-3 py-1 rounded-full text-sm font-medium ${getWorkloadColor(member.workloadPercentage)}`}>
                  {member.workloadPercentage}%
                </div>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-lg font-bold text-gray-900">{member.completedTasks}</div>
                  <div className="text-xs text-gray-600">Tamamlanan</div>
                </div>
                <div className="text-center p-3 bg-gray-50 rounded-lg">
                  <div className="text-lg font-bold text-gray-900">{member.inProgressTasks}</div>
                  <div className="text-xs text-gray-600">Devam Eden</div>
                </div>
              </div>

              {/* Workload Bar */}
              <div className="mb-4">
                <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                  <span>İş Yoğunluğu</span>
                  <span>{member.workloadPercentage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full transition-all duration-300 ${
                      member.workloadPercentage >= 90 ? 'bg-red-500' :
                      member.workloadPercentage >= 70 ? 'bg-orange-500' :
                      member.workloadPercentage >= 50 ? 'bg-yellow-500' : 'bg-green-500'
                    }`}
                    style={{ width: `${member.workloadPercentage}%` }}
                  ></div>
                </div>
              </div>

              {/* Efficiency */}
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-600">Verimlilik</span>
                <span className="font-medium text-gray-900">{member.efficiency}%</span>
              </div>

              {/* Expanded Details */}
              {selectedMember === member.id && (
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <h4 className="text-sm font-semibold text-gray-900 mb-3">Mevcut Görevler</h4>
                  <div className="space-y-3">
                    {member.currentTasks.map((task, index) => (
                      <div key={index} className="p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-start justify-between mb-2">
                          <h5 className="text-sm font-medium text-gray-900 line-clamp-1">
                            {task.title}
                          </h5>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(task.priority)}`}>
                            {task.priority === 'critical' ? 'Kritik' :
                             task.priority === 'high' ? 'Yüksek' :
                             task.priority === 'medium' ? 'Orta' : 'Düşük'}
                          </span>
                        </div>
                        
                        <div className="flex items-center text-xs text-gray-600 mb-2">
                          <Calendar className="w-3 h-3 mr-1" />
                          <span>{new Date(task.dueDate).toLocaleDateString('tr-TR')}</span>
                        </div>
                        
                        <div className="flex items-center justify-between text-xs text-gray-600">
                          <span>İlerleme</span>
                          <span>{task.progress}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-1 mt-1">
                          <div 
                            className={`h-1 rounded-full transition-all duration-300 ${
                              task.progress >= 90 ? 'bg-gradient-to-r from-green-400 to-green-600' :
                              task.progress >= 70 ? 'bg-gradient-to-r from-yellow-400 to-green-500' :
                              task.progress >= 50 ? 'bg-gradient-to-r from-orange-400 to-yellow-500' :
                              task.progress >= 25 ? 'bg-gradient-to-r from-red-400 to-orange-500' :
                              'bg-gradient-to-r from-red-500 to-red-600'
                            }`}
                            style={{ width: `${task.progress}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Workload Distribution Chart */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-6">İş Yükü Dağılımı</h3>
        
        <div className="space-y-4">
          {teamMembers.map((member) => (
            <div key={member.id} className="flex items-center space-x-4">
              <div className="w-32 text-sm font-medium text-gray-900 truncate">
                {member.name}
              </div>
              
              <div className="flex-1 relative">
                <div className="w-full bg-gray-200 rounded-full h-6">
                  <div 
                    className={`h-6 rounded-full flex items-center justify-end pr-2 text-xs font-medium text-white transition-all duration-300 ${
                      member.workloadPercentage >= 90 ? 'bg-red-500' :
                      member.workloadPercentage >= 70 ? 'bg-orange-500' :
                      member.workloadPercentage >= 50 ? 'bg-yellow-500' : 'bg-green-500'
                    }`}
                    style={{ width: `${member.workloadPercentage}%` }}
                  >
                    {member.workloadPercentage}%
                  </div>
                </div>
              </div>
              
              <div className="w-20 text-sm text-gray-600 text-right">
                {member.inProgressTasks} görev
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TeamWorkload;
import React, { useState, useEffect } from 'react'
import { MessageSquare, Bell, Share2, Eye, Users, Clock } from 'lucide-react'

interface Notification {
  id: number
  type: 'task_update' | 'task_completed' | 'new_task' | 'deadline_approaching'
  message: string
  user: string
  timestamp: Date
  read: boolean
}

const TeamCollaboration: React.FC = () => {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: 1,
      type: 'task_completed',
      message: 'Operatör Eğitim Programı tamamlandı',
      user: 'Ali Özkan',
      timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 dakika önce
      read: false
    },
    {
      id: 2,
      type: 'task_update',
      message: 'Plastik Enjeksiyon Kalıp Revizyonu %75 tamamlandı',
      user: 'Ahmet Yılmaz',
      timestamp: new Date(Date.now() - 1000 * 60 * 60), // 1 saat önce
      read: false
    },
    {
      id: 3,
      type: 'deadline_approaching',
      message: 'Boya Kabini Filtre Değişimi yarın bitiyor',
      user: 'Sistem',
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 saat önce
      read: true
    }
  ])

  const [showNotifications, setShowNotifications] = useState(false)
  const unreadCount = notifications.filter(n => !n.read).length

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'task_completed':
        return '✅'
      case 'task_update':
        return '📝'
      case 'new_task':
        return '🆕'
      case 'deadline_approaching':
        return '⏰'
      default:
        return '📢'
    }
  }

  const formatTimeAgo = (date: Date) => {
    const now = new Date()
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60))
    
    if (diffInMinutes < 60) {
      return `${diffInMinutes} dakika önce`
    } else if (diffInMinutes < 1440) {
      return `${Math.floor(diffInMinutes / 60)} saat önce`
    } else {
      return `${Math.floor(diffInMinutes / 1440)} gün önce`
    }
  }

  return (
    <div className="fixed top-4 right-4 z-50">
      <div className="flex items-center space-x-4">
        {/* Online Users Indicator */}
        <div className="bg-white rounded-lg shadow-lg border border-gray-200 px-3 py-2">
          <div className="flex items-center space-x-2">
            <div className="flex -space-x-2">
              {['AY', 'MK', 'FD', 'AÖ', 'ZA'].map((initials, index) => (
                <div
                  key={initials}
                  className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white text-xs font-semibold border-2 border-white"
                  style={{ zIndex: 5 - index }}
                >
                  {initials}
                </div>
              ))}
            </div>
            <div className="flex items-center text-sm text-gray-600">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-1"></div>
              <span>5 aktif</span>
            </div>
          </div>
        </div>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="bg-white rounded-lg shadow-lg border border-gray-200 p-3 hover:bg-gray-50 transition-colors duration-200 relative"
          >
            <Bell className="w-5 h-5 text-gray-600" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>

          {showNotifications && (
            <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-xl border border-gray-200 max-h-96 overflow-y-auto">
              <div className="p-4 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900">Bildirimler</h3>
              </div>
              
              <div className="divide-y divide-gray-200">
                {notifications.map((notification) => (
                  <div
                    key={notification.id}
                    className={`p-4 hover:bg-gray-50 transition-colors duration-200 ${
                      !notification.read ? 'bg-blue-50' : ''
                    }`}
                  >
                    <div className="flex items-start space-x-3">
                      <span className="text-lg">{getNotificationIcon(notification.type)}</span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-gray-900">{notification.message}</p>
                        <div className="flex items-center justify-between mt-1">
                          <p className="text-xs text-gray-500">{notification.user}</p>
                          <p className="text-xs text-gray-500">{formatTimeAgo(notification.timestamp)}</p>
                        </div>
                      </div>
                      {!notification.read && (
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="p-4 border-t border-gray-200">
                <button className="w-full text-center text-sm text-blue-600 hover:text-blue-800 transition-colors duration-200">
                  Tümünü okundu olarak işaretle
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Share Button */}
        <button className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg shadow-lg px-4 py-3 hover:from-blue-700 hover:to-purple-700 transition-all duration-200 flex items-center">
          <Share2 className="w-4 h-4 mr-2" />
          <span className="text-sm font-medium">Paylaş</span>
        </button>
      </div>
    </div>
  )
}

export default TeamCollaboration
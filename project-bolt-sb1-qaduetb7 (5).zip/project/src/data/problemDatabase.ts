export interface ProblemType {
  id: string;
  name: string;
  category: string;
  rootCauses: string[];
  solutions: string[];
  preventiveMeasures: string[];
  technicalDetails: string;
}

export const problemDatabase: ProblemType[] = [
  {
    id: "short_shot",
    name: "Eksik Baskı (Short Shot)",
    category: "Plastik Enjeksiyon",
    rootCauses: [
      "Enjeksiyon basıncının düşük olması",
      "Kalıp havalandırmasının yetersizliği",
      "Dolum süresinin kısa tutulması",
      "Malzeme nemli olması",
      "Enjeksiyon ucu (nozul) tıkanıklığı",
      "Kalıp içi sıcaklık dengesizliği",
      "Yanlış giriş noktası tasarımı",
      "Enjeksiyon makinesi vida aşınması",
      "Hammaddenin akışkanlığının düşük olması (MFI)",
      "Soğutma hatlarının düzensizliği",
      "Makine parametre hatası – dolum basıncı yetersiz",
      "Operatör dikkatsizliği – dolum süresi yanlış ayarlanmış",
      "Yanlış malzeme seçimi – düşük akışkanlık MFI",
      "Kalıp aşınması – yolluklar daralmış",
      "Yanlış proses ayarı – tutma basıncı kısa",
      "Çevresel koşulların uygunsuzluğu – ortam nemi yüksek",
      "Bakım eksikliği – nozul tıkalı",
      "Yanlış tasarım – dolum noktası uzak",
      "Yanlış fikstür kullanımı – kalıp tam kapanmıyor",
      "Nem kontrol eksikliği – hammadde nemli"
    ],
    solutions: [
      "Basınç sensörü ile sürekli takip sistemi kurulması",
      "Kalıp havalandırma deliklerinin artırılması ve temizlenmesi",
      "Dolum süresinin optimizasyonu ve standardizasyonu",
      "Hammadde kurutma sisteminin iyileştirilmesi",
      "Nozul temizlik prosedürünün düzenli uygulanması",
      "Soğutma sisteminin optimizasyonu ve balanslanması",
      "Giriş noktası tasarımının revize edilmesi",
      "Vida bakım programının oluşturulması",
      "MFI değeri uygun malzeme seçimi",
      "Soğutma hatlarının yeniden tasarlanması"
    ],
    preventiveMeasures: [
      "Günlük basınç kontrol rutini",
      "Haftalık kalıp temizlik programı",
      "Hammadde nem ölçümü protokolü",
      "Operatör eğitim programı",
      "Makine bakım takvimi"
    ],
    technicalDetails: "Eksik baskı, enjeksiyon kalıplama sürecinde malzemenin kalıp boşluğunu tamamen dolduramaması sonucu oluşan kalite hatasıdır. Bu problem genellikle basınç, sıcaklık ve akış parametrelerinin optimum değerlerde olmamasından kaynaklanır."
  },
  {
    id: "burn_marks",
    name: "Yanık İzleri (Burn Marks)",
    category: "Plastik Enjeksiyon",
    rootCauses: [
      "Kalıp havalandırma yetersizliği",
      "Fazla enjeksiyon hızı",
      "Yüksek eriyik sıcaklığı",
      "Havanın sıkışması",
      "Yanlış giriş noktası seçimi",
      "Kalıp yüzey pürüzlülüğü",
      "Kalıp kanal çapının dar olması",
      "Plastik akış yolunun uzunluğu",
      "Yüksek nemli malzeme",
      "Vida sıkıştırma basıncının yüksekliği",
      "Makine parametre hatası – hız çok yüksek",
      "Operatör dikkatsizliği – parametre değişmemiş",
      "Yanlış malzeme seçimi – nemli granül",
      "Kalıp aşınması – havalandırma delikleri daralmış",
      "Yanlış proses ayarı – sıcaklık fazla",
      "Çevresel koşulların uygunsuzluğu – hava dolaşımı kötü",
      "Bakım eksikliği – kalıp havalandırması temizlenmemiş",
      "Yanlış tasarım – hava çıkış yetersiz",
      "Yanlış fikstür – kalıp kapak tam oturmamış",
      "Nem kontrol eksikliği – hammadde kurutulmamış"
    ],
    solutions: [
      "Havalandırma sisteminin artırılması",
      "Enjeksiyon hızının optimize edilmesi",
      "Malzeme kurutma prosedürünün uygulanması",
      "Sıcaklık profilinin ayarlanması",
      "Kalıp kanal tasarımının iyileştirilmesi",
      "Giriş noktası pozisyonunun revize edilmesi"
    ],
    preventiveMeasures: [
      "Günlük havalandırma kontrol rutini",
      "Sıcaklık profili takip sistemi",
      "Malzeme nem ölçümü",
      "Hız parametre standardizasyonu"
    ],
    technicalDetails: "Yanık izleri, kalıp boşluğunda sıkışan havanın yüksek basınç ve sıcaklık altında yanması sonucu oluşan kahverengi-siyah renkte izlerdir. Bu durum özellikle havalandırma yetersizliği ve yüksek enjeksiyon hızlarında görülür."
  },
  {
    id: "flash_burr",
    name: "Çapak (Burr/Flash)",
    category: "Plastik Enjeksiyon",
    rootCauses: [
      "Kalıp kapama basıncının düşük olması",
      "Kalıp yüzeylerinde aşınma",
      "Enjeksiyon basıncının fazla olması",
      "Kalıp hizalanma sorunu",
      "Sıcak koşullarda kalıp deformasyonu",
      "Yanlış parça geometrisi",
      "Yanlış ayarlanmış kilitleme kuvveti",
      "Soğutma dengesizliği",
      "Uygun olmayan kalıp çeliği",
      "Operatör yanlış ayarı",
      "Makine parametre hatası – kapama basıncı düşük",
      "Operatör dikkatsizliği – basınç ayarı yapılmamış",
      "Yanlış malzeme seçimi – fazla akışkan",
      "Kalıp aşınması – yüzeyler boşluklu",
      "Yanlış proses ayarı – enjeksiyon basıncı yüksek",
      "Çevresel koşullar – kalıp ısınmış",
      "Bakım eksikliği – kalıp yüzeyinde çapak kalmış",
      "Yanlış tasarım – parça et kalınlığı fazla",
      "Yanlış fikstür – kalıp sıkılmamış",
      "Nem kontrol eksikliği – malzeme akışı dengesiz"
    ],
    solutions: [
      "Kalıp bakım programının oluşturulması",
      "Kapama basıncının artırılması",
      "Kalıp hizalamasının kontrol edilmesi",
      "Kilitleme kuvvetinin optimizasyonu",
      "Kalıp yüzey işlemlerinin iyileştirilmesi"
    ],
    preventiveMeasures: [
      "Günlük kalıp kontrol rutini",
      "Basınç kalibrasyonu",
      "Hizalama ölçümü",
      "Yüzey kalitesi takibi"
    ],
    technicalDetails: "Çapak, kalıp ayırma yüzeylerinden taşan fazla malzeme nedeniyle oluşan ince film tabakasıdır. Bu durum genellikle yetersiz kapama basıncı veya kalıp yüzey problemlerinden kaynaklanır."
  },
  {
    id: "sink_marks",
    name: "Çekinti İzleri (Sink Marks)",
    category: "Plastik Enjeksiyon",
    rootCauses: [
      "Et kalınlığının fazla olması",
      "Yetersiz tutma basıncı",
      "Tutma süresinin kısa olması",
      "Malzemenin büzülme oranı yüksek",
      "Yanlış yolluk tasarımı",
      "Kalıp soğutmasının dengesiz olması",
      "Yanlış malzeme seçimi",
      "Dolum hızının yetersizliği",
      "Yanlış geometrik tasarım",
      "Vida/torna hatası",
      "Et kalınlığı fazla tasarlanmış",
      "Tutma basıncı yetersiz",
      "Tutma süresi kısa ayarlanmış",
      "Soğutma kanalları dengesiz",
      "Yanlış malzeme seçimi (yüksek büzülme)",
      "Yanlış yolluk tasarımı",
      "Dolum hızı düşük",
      "Kalıp yüzeyinde sıcak-soğuk bölgeler",
      "Yanlış proses parametresi",
      "Vida sıkıştırması uygunsuz"
    ],
    solutions: [
      "Et kalınlığının azaltılması",
      "Tutma basıncının artırılması",
      "Kalıp soğutma sisteminin optimize edilmesi",
      "Malzeme seçiminin revize edilmesi",
      "Yolluk tasarımının iyileştirilmesi"
    ],
    preventiveMeasures: [
      "Tasarım aşamasında et kalınlığı kontrolü",
      "Soğutma sistemi analizi",
      "Malzeme büzülme oranı takibi"
    ],
    technicalDetails: "Çekinti izleri, kalın et kesitlerinde malzemenin soğuma sırasında büzülmesi sonucu yüzeyde oluşan çöküntülerdir. Bu durum özellikle yetersiz tutma basıncı ve dengesiz soğutmada görülür."
  },
  {
    id: "color_variation",
    name: "Renk Ton Farklılığı",
    category: "Plastik Enjeksiyon",
    rootCauses: [
      "Masterbatch oranı değişken",
      "Hammaddenin nemli olması",
      "Farklı lot malzeme kullanımı",
      "Yanlış sıcaklık profili",
      "Vida devri uygunsuz",
      "Karıştırma yetersiz",
      "Pigment dağılmaması",
      "Yanlış dozajlama ekipmanı",
      "Malzeme akış hızı farklılıkları",
      "Yanlış depolama koşulları",
      "Masterbatch oranı değişken",
      "Pigment homojen karışmamış",
      "Lot farklılığı",
      "Hammaddenin nemi",
      "Sıcaklık profili uygunsuz",
      "Vida devri yanlış",
      "Yanlış seyreltici oranı",
      "Malzeme depolama uygunsuz",
      "Dozajlama cihazı kalibrasyonsuz",
      "Farklı üretim hattı kullanımı"
    ],
    solutions: [
      "Masterbatch dozajının kalibre edilmesi",
      "Hammadde kurutma prosedürünün uygulanması",
      "Lot takip sisteminin kurulması",
      "Renk ölçüm cihazı ile kontrol",
      "Karıştırma parametrelerinin standardizasyonu"
    ],
    preventiveMeasures: [
      "Günlük renk kontrol rutini",
      "Lot takip sistemi",
      "Dozajlama kalibrasyonu",
      "Depolama koşulları kontrolü"
    ],
    technicalDetails: "Renk ton farklılığı, pigment dağılımının homojen olmaması veya proses parametrelerindeki değişkenlik nedeniyle aynı parti içinde farklı renk tonlarının oluşmasıdır."
  }
];

export const getRelevantProblems = (description: string, category: string): ProblemType[] => {
  const keywords = description.toLowerCase().split(' ');
  
  return problemDatabase.filter(problem => {
    const matchesCategory = category === 'all' || problem.category.toLowerCase().includes(category.toLowerCase());
    const matchesKeywords = keywords.some(keyword => 
      problem.name.toLowerCase().includes(keyword) ||
      problem.rootCauses.some(cause => cause.toLowerCase().includes(keyword)) ||
      problem.technicalDetails.toLowerCase().includes(keyword)
    );
    
    return matchesCategory || matchesKeywords;
  });
};

export const generateTechnicalAnalysis = (problemData: any, relevantProblems: ProblemType[]): any => {
  const analysis = {
    problemType: problemData.category || "Kalite Hatası",
    rootCause: "Çok faktörlü problem - detaylı analiz gerekli",
    immediateActions: [
      "Etkilenen ürünlerin karantinaya alınması",
      "Mevcut sürecin durdurulması ve incelenmesi",
      "Acil kalite kontrol noktalarının eklenmesi"
    ],
    eightD: {
      d1: "Kalite Mühendisi, Üretim Sorumlusu, Proses Mühendisi, Operatör Temsilcisi",
      d2: `Problem: ${problemData.title}\nEtki: ${problemData.customerImpact}\nKapsam: ${problemData.department}\nKeşif Tarihi: ${problemData.discoveryDate}`,
      d3: "Geçici kalite kontrol noktaları eklendi, etkilenen ürünler karantinaya alındı, süreç parametreleri gözden geçirildi",
      d4: "Kök neden analizi devam ediyor - Fishbone diyagramı ve 5 Neden analizi uygulanacak",
      d5: "Kalıcı düzeltici eylemlerin belirlenmesi için kök neden analizinin tamamlanması bekleniyor",
      d6: "Düzeltici eylemlerin uygulanması ve etkinlik kontrolü yapılacak",
      d7: "Benzer problemlerin tekrarını önlemek için sistem iyileştirmeleri yapılacak",
      d8: "Başarılı problem çözümü sonrası takım performansının değerlendirilmesi"
    },
    confidence: 75,
    recommendations: [
      "Detaylı kök neden analizi yapılması",
      "Proses parametrelerinin standardizasyonu",
      "Operatör eğitim programının güncellenmesi",
      "Preventif kalite kontrol sistemlerinin kurulması"
    ]
  };

  // Eğer veritabanında benzer problem varsa, daha spesifik analiz yap
  if (relevantProblems.length > 0) {
    const mostRelevant = relevantProblems[0];
    
    analysis.rootCause = mostRelevant.rootCauses.slice(0, 3).join(", ");
    analysis.immediateActions = mostRelevant.solutions.slice(0, 3);
    analysis.recommendations = mostRelevant.preventiveMeasures;
    analysis.confidence = 85;
    
    // 8D analizi güncelle
    analysis.eightD.d4 = `Kök neden: ${mostRelevant.rootCauses.slice(0, 2).join(" ve ")}. ${mostRelevant.technicalDetails}`;
    analysis.eightD.d5 = mostRelevant.solutions.slice(0, 2).join(" ve ");
    analysis.eightD.d7 = mostRelevant.preventiveMeasures.join(", ");
  }

  return analysis;
};
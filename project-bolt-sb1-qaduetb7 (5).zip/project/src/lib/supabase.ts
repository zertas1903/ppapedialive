import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://placeholder.supabase.co'
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'placeholder-key'

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  realtime: {
    params: {
      eventsPerSecond: 10
    }
  }
})

// Gerçek zamanlı bağlantı durumu
export const checkConnection = async () => {
  try {
    // Check if we're using placeholder credentials
    if (supabaseUrl.includes('placeholder') || supabaseAnonKey.includes('placeholder')) {
      return { 
        connected: false, 
        error: new Error('Demo modu - Supabase yapılandırması gerekli') 
      };
    }
    
    const { data, error } = await supabase.from('tasks').select('count').limit(1);
    return { connected: !error, error };
  } catch (err) {
    return { 
      connected: false, 
      error: err instanceof Error ? err : new Error('Bilinmeyen bağlantı hatası') 
    };
  }
}
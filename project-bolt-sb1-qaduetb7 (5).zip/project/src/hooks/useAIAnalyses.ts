import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

export interface AIAnalysis {
  id: string
  title: string
  category: string
  description?: string
  analysis_result?: any
  confidence: number
  rating: number
  status: 'completed' | 'in_progress' | 'pending'
  user_id: string
  created_at: string
  updated_at: string
}

export const useAIAnalyses = () => {
  const [analyses, setAnalyses] = useState<AIAnalysis[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Check if we're using placeholder credentials
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://placeholder.supabase.co'
    const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'placeholder-key'
    
    if (supabaseUrl.includes('placeholder') || supabaseAnonKey.includes('placeholder')) {
      // Use mock data when Supabase is not configured
      const mockAnalyses: AIAnalysis[] = [
        {
          id: '1',
          title: 'Eksik Baskı Problemi',
          category: 'Plastik Enjeksiyon',
          description: 'Enjeksiyon kalıplama sürecinde malzemenin kalıp boşluğunu tamamen dolduramaması',
          analysis_result: {
            problemType: 'Plastik Enjeksiyon Hatası',
            rootCause: 'Enjeksiyon basıncının düşük olması, kalıp havalandırmasının yetersizliği',
            confidence: 89,
            immediateActions: [
              'Basınç sensörü ile sürekli takip sistemi kurulması',
              'Kalıp havalandırma deliklerinin artırılması',
              'Dolum süresinin optimizasyonu'
            ],
            recommendations: [
              'Günlük basınç kontrol rutini',
              'Haftalık kalıp temizlik programı',
              'Operatör eğitim programı'
            ]
          },
          confidence: 89,
          rating: 5,
          status: 'completed',
          user_id: 'demo-user',
          created_at: '2025-01-10T08:00:00Z',
          updated_at: '2025-01-10T08:00:00Z'
        },
        {
          id: '2',
          title: 'Yanık İzleri',
          category: 'Plastik Enjeksiyon',
          description: 'Kalıp boşluğunda sıkışan havanın yüksek basınç ve sıcaklık altında yanması',
          analysis_result: {
            problemType: 'Yanık İzleri',
            rootCause: 'Kalıp havalandırma yetersizliği, fazla enjeksiyon hızı',
            confidence: 92,
            immediateActions: [
              'Havalandırma sisteminin artırılması',
              'Enjeksiyon hızının optimize edilmesi',
              'Malzeme kurutma prosedürünün uygulanması'
            ],
            recommendations: [
              'Günlük havalandırma kontrol rutini',
              'Sıcaklık profili takip sistemi',
              'Malzeme nem ölçümü'
            ]
          },
          confidence: 92,
          rating: 4,
          status: 'completed',
          user_id: 'demo-user',
          created_at: '2025-01-09T10:00:00Z',
          updated_at: '2025-01-09T10:00:00Z'
        },
        {
          id: '3',
          title: 'Renk Ton Farklılığı',
          category: 'Plastik Enjeksiyon',
          description: 'Pigment dağılımının homojen olmaması nedeniyle farklı renk tonları',
          analysis_result: {
            problemType: 'Renk Kalitesi Hatası',
            rootCause: 'Masterbatch oranı değişken, pigment homojen karışmamış',
            confidence: 76,
            immediateActions: [
              'Masterbatch dozajının kalibre edilmesi',
              'Hammadde kurutma prosedürünün uygulanması',
              'Lot takip sisteminin kurulması'
            ],
            recommendations: [
              'Günlük renk kontrol rutini',
              'Lot takip sistemi',
              'Dozajlama kalibrasyonu'
            ]
          },
          confidence: 76,
          rating: 4,
          status: 'in_progress',
          user_id: 'demo-user',
          created_at: '2025-01-08T14:00:00Z',
          updated_at: '2025-01-08T14:00:00Z'
        }
      ]
      
      setAnalyses(mockAnalyses)
      setLoading(false)
      setError(null) // Demo modunda hata gösterme
      return
    }

    // İlk veri yükleme
    const fetchAnalyses = async () => {
      try {
        const { data, error } = await supabase
          .from('ai_analyses')
          .select('*')
          .order('created_at', { ascending: false })

        if (error) throw error
        setAnalyses(data || [])
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Veri yüklenirken hata oluştu')
      } finally {
        setLoading(false)
      }
    }

    fetchAnalyses()

    // Gerçek zamanlı güncellemeler
    const channel = supabase
      .channel('ai_analyses_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'ai_analyses'
        },
        (payload) => {
          console.log('AI Analiz güncelleme:', payload)
          
          if (payload.eventType === 'INSERT') {
            setAnalyses(prev => [payload.new as AIAnalysis, ...prev])
          } else if (payload.eventType === 'UPDATE') {
            setAnalyses(prev => prev.map(analysis => 
              analysis.id === payload.new.id ? payload.new as AIAnalysis : analysis
            ))
          } else if (payload.eventType === 'DELETE') {
            setAnalyses(prev => prev.filter(analysis => analysis.id !== payload.old.id))
          }
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  const addAnalysis = async (analysisData: Omit<AIAnalysis, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      const { data, error } = await supabase
        .from('ai_analyses')
        .insert([analysisData])
        .select()
        .single()

      if (error) throw error
      return data
    } catch (err) {
      console.error('Analiz eklenirken hata:', err)
      throw err
    }
  }

  const updateAnalysisRating = async (id: string, rating: number) => {
    try {
      const { data, error } = await supabase
        .from('ai_analyses')
        .update({ rating, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single()

      if (error) throw error
      return data
    } catch (err) {
      console.error('Rating güncellenirken hata:', err)
      throw err
    }
  }

  return { 
    analyses, 
    loading, 
    error, 
    addAnalysis, 
    updateAnalysisRating,
    setAnalyses 
  }
}

export const useAIStats = () => {
  const [stats, setStats] = useState({
    totalAnalyses: 0,
    completedAnalyses: 0,
    averageRating: 0,
    averageConfidence: 0
  })

  useEffect(() => {
    const fetchStats = async () => {
      const { data } = await supabase
        .from('ai_analyses')
        .select('rating, confidence, status')

      if (data) {
        const total = data.length
        const completed = data.filter(a => a.status === 'completed').length
        const avgRating = data.reduce((sum, a) => sum + (a.rating || 0), 0) / total
        const avgConfidence = data.reduce((sum, a) => sum + (a.confidence || 0), 0) / total

        setStats({
          totalAnalyses: total,
          completedAnalyses: completed,
          averageRating: Math.round(avgRating * 10) / 10,
          averageConfidence: Math.round(avgConfidence)
        })
      }
    }

    fetchStats()

    // Her 30 saniyede bir istatistikleri güncelle
    const interval = setInterval(fetchStats, 30000)
    return () => clearInterval(interval)
  }, [])

  return stats
}
import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

export interface Task {
  id: number
  title: string
  description: string
  assignee: string
  due_date: string
  priority: 'low' | 'medium' | 'high' | 'critical'
  status: 'todo' | 'in_progress' | 'review' | 'completed'
  category: string
  estimated_hours: number
  completed_hours: number
  tags: string[]
  created_at: string
  updated_at: string
}

export const useRealTimeTasks = () => {
  const [tasks, setTasks] = useState<Task[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Check if we're using placeholder credentials
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://placeholder.supabase.co'
    const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'placeholder-key'
    
    if (supabaseUrl.includes('placeholder') || supabaseAnonKey.includes('placeholder')) {
      // Use mock data when Supabase is not configured
      const mockTasks: Task[] = [
        {
          id: 1,
          title: 'Plastik Enjeksiyon Kalıp Revizyonu',
          description: 'Kalıp parametrelerinin optimizasyonu ve revizyon işlemleri',
          assignee: 'Ahmet Yılmaz',
          due_date: '2025-01-15',
          priority: 'high',
          status: 'in_progress',
          category: 'Mühendislik',
          estimated_hours: 40,
          completed_hours: 27,
          tags: ['kalıp', 'revizyon', 'optimizasyon'],
          created_at: '2025-01-10T08:00:00Z',
          updated_at: '2025-01-12T14:30:00Z'
        },
        {
          id: 2,
          title: 'Boya Kabini Filtre Değişimi',
          description: 'Periyodik bakım kapsamında filtre değişimi',
          assignee: 'Mehmet Kaya',
          due_date: '2025-01-12',
          priority: 'medium',
          status: 'todo',
          category: 'Bakım',
          estimated_hours: 4,
          completed_hours: 0,
          tags: ['bakım', 'filtre', 'boya'],
          created_at: '2025-01-08T09:00:00Z',
          updated_at: '2025-01-08T09:00:00Z'
        },
        {
          id: 3,
          title: 'Operatör Eğitim Programı',
          description: 'Yeni operatörler için temel eğitim programı',
          assignee: 'Ali Özkan',
          due_date: '2025-01-19',
          priority: 'medium',
          status: 'completed',
          category: 'Eğitim',
          estimated_hours: 16,
          completed_hours: 16,
          tags: ['eğitim', 'operatör', 'temel'],
          created_at: '2025-01-05T10:00:00Z',
          updated_at: '2025-01-11T16:00:00Z'
        }
      ]
      
      setTasks(mockTasks)
      setLoading(false)
      setError(null) // Demo modunda hata gösterme
      return
    }

    // İlk veri yükleme
    const fetchTasks = async () => {
      try {
        const { data, error } = await supabase
          .from('tasks')
          .select('*')
          .order('created_at', { ascending: false })

        if (error) throw error
        setTasks(data || [])
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Veri yüklenirken hata oluştu')
      } finally {
        setLoading(false)
      }
    }

    fetchTasks()

    // Gerçek zamanlı güncellemeler
    const channel = supabase
      .channel('tasks_changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'tasks'
        },
        (payload) => {
          console.log('Gerçek zamanlı güncelleme:', payload)
          
          if (payload.eventType === 'INSERT') {
            setTasks(prev => [payload.new as Task, ...prev])
          } else if (payload.eventType === 'UPDATE') {
            setTasks(prev => prev.map(task => 
              task.id === payload.new.id ? payload.new as Task : task
            ))
          } else if (payload.eventType === 'DELETE') {
            setTasks(prev => prev.filter(task => task.id !== payload.old.id))
          }
        }
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  return { tasks, loading, error, setTasks }
}

export const useRealTimeTeamStats = () => {
  const [stats, setStats] = useState({
    totalTasks: 0,
    completedTasks: 0,
    inProgressTasks: 0,
    overdueTasks: 0
  })

  useEffect(() => {
    const fetchStats = async () => {
      const { data } = await supabase
        .from('tasks')
        .select('status, due_date')

      if (data) {
        const now = new Date()
        const total = data.length
        const completed = data.filter(t => t.status === 'completed').length
        const inProgress = data.filter(t => t.status === 'in_progress').length
        const overdue = data.filter(t => 
          t.status !== 'completed' && new Date(t.due_date) < now
        ).length

        setStats({
          totalTasks: total,
          completedTasks: completed,
          inProgressTasks: inProgress,
          overdueTasks: overdue
        })
      }
    }

    fetchStats()

    // Her 30 saniyede bir istatistikleri güncelle
    const interval = setInterval(fetchStats, 30000)
    return () => clearInterval(interval)
  }, [])

  return stats
}
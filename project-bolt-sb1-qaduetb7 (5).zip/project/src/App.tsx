import React, { useState } from 'react';
import { Brain, FileText, TrendingUp, Settings, CheckSquare, Users, Calendar, BarChart3 } from 'lucide-react';
import Header from './components/Header';
import LoginPage from './components/LoginPage';
import LandingPage from './components/LandingPage';
import ProblemForm from './components/ProblemForm';
import Dashboard from './components/Dashboard';
import ReportHistory from './components/ReportHistory';
import Settings8D from './components/Settings8D';
import WorkTracker from './components/WorkTracker';
import WorkDashboard from './components/WorkDashboard';
import TeamWorkload from './components/TeamWorkload';
import CpkCalculator from './components/CpkCalculator';
import TeamCollaboration from './components/TeamCollaboration';
import PowerBIDashboard from './components/PowerBIDashboard';
import ReverseFMEA from './components/ReverseFMEA';
import AIAuditor from './components/AIAuditor';
type AppMode = 'landing' | '8d' | 'work' | 'calculations' | 'reverse-fmea' | 'ai-auditor';
type Tab8D = 'form' | 'dashboard' | 'history' | 'settings';
type TabWork = 'tracker' | 'dashboard' | 'team' | 'settings';
type TabCalculations = 'cpk' | 'powerbi' | 'settings';
type TabReverseFMEA = 'upload' | 'create' | 'analyze' | 'settings';
type TabAIAuditor = 'upload' | 'analyze' | 'report' | 'settings';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState<string>('');
  const [appMode, setAppMode] = useState<AppMode>('landing');
  const [active8DTab, setActive8DTab] = useState<Tab8D>('form');
  const [activeWorkTab, setActiveWorkTab] = useState<TabWork>('tracker');
  const [activeCalculationsTab, setActiveCalculationsTab] = useState<TabCalculations>('cpk');
  const [activeReverseFMEATab, setActiveReverseFMEATab] = useState<TabReverseFMEA>('upload');
  const [activeAIAuditorTab, setActiveAIAuditorTab] = useState<TabAIAuditor>('upload');

  // Sayfa yüklendiğinde oturum kontrolü
  React.useEffect(() => {
    const savedUser = localStorage.getItem('ppapedia_user');
    if (savedUser) {
      const userInfo = JSON.parse(savedUser);
      setCurrentUser(userInfo.username);
      setIsAuthenticated(true);
    }
  }, []);

  const handleLogin = (username: string) => {
    setCurrentUser(username);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setCurrentUser('');
    setIsAuthenticated(false);
    setAppMode('landing');
  };

  // Giriş yapılmamışsa login sayfasını göster
  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  const tabs8D = [
    { id: 'form' as const, label: 'Problem Analizi', icon: Brain },
    { id: 'dashboard' as const, label: 'Dashboard', icon: TrendingUp },
    { id: 'history' as const, label: 'Rapor Geçmişi', icon: FileText },
    { id: 'settings' as const, label: 'Ayarlar', icon: Settings }
  ];

  const tabsWork = [
    { id: 'tracker' as const, label: 'İş Takip Listem', icon: CheckSquare },
    { id: 'dashboard' as const, label: 'Dashboard', icon: BarChart3 },
    { id: 'team' as const, label: 'Ekip Yoğunluğu', icon: Users },
    { id: 'settings' as const, label: 'Ayarlar', icon: Settings }
  ];

  const tabsCalculations = [
    { id: 'cpk' as const, label: 'Cp/Cpk Hesaplama', icon: BarChart3 },
    { id: 'powerbi' as const, label: 'Power BI Dashboard', icon: TrendingUp },
    { id: 'settings' as const, label: 'Ayarlar', icon: Settings }
  ];

  const tabsReverseFMEA = [
    { id: 'upload' as const, label: 'FMEA Yükle', icon: FileText },
    { id: 'create' as const, label: 'Manuel FMEA', icon: Brain },
    { id: 'analyze' as const, label: 'AI Analizi', icon: TrendingUp },
    { id: 'settings' as const, label: 'Ayarlar', icon: Settings }
  ];

  const tabsAIAuditor = [
    { id: 'upload' as const, label: 'Doküman Yükle', icon: FileText },
    { id: 'analyze' as const, label: 'AI Denetimi', icon: Brain },
    { id: 'report' as const, label: 'Denetim Raporu', icon: TrendingUp },
    { id: 'settings' as const, label: 'Ayarlar', icon: Settings }
  ];

  const render8DContent = () => {
    switch (active8DTab) {
      case 'form':
        return <ProblemForm />;
      case 'dashboard':
        return <Dashboard />;
      case 'history':
        return <ReportHistory />;
      case 'settings':
        return <Settings8D />;
      default:
        return <ProblemForm />;
    }
  };

  const renderWorkContent = () => {
    switch (activeWorkTab) {
      case 'tracker':
        return <WorkTracker />;
      case 'dashboard':
        return <WorkDashboard />;
      case 'team':
        return <TeamWorkload />;
      case 'settings':
        return <Settings8D />;
      default:
        return <WorkTracker />;
    }
  };

  const renderCalculationsContent = () => {
    switch (activeCalculationsTab) {
      case 'cpk':
        return <CpkCalculator />;
      case 'powerbi':
        return <PowerBIDashboard />;
      case 'settings':
        return <Settings8D />;
      default:
        return <CpkCalculator />;
    }
  };

  const renderReverseFMEAContent = () => {
    return <ReverseFMEA />;
  };

  const renderAIAuditorContent = () => {
    return <AIAuditor />;
  };

  if (appMode === 'landing') {
    return <LandingPage onModeSelect={setAppMode} />;
  }

  const currentTabs = appMode === '8d' ? tabs8D : 
                     appMode === 'work' ? tabsWork : 
                     appMode === 'reverse-fmea' ? tabsReverseFMEA : 
                     appMode === 'ai-auditor' ? tabsAIAuditor :
                     tabsCalculations;
  
  const activeTab = appMode === '8d' ? active8DTab : 
                   appMode === 'work' ? activeWorkTab : 
                   appMode === 'reverse-fmea' ? activeReverseFMEATab :
                   appMode === 'ai-auditor' ? activeAIAuditorTab :
                   activeCalculationsTab;
  
  const setActiveTab = appMode === '8d' ? setActive8DTab : 
                      appMode === 'work' ? setActiveWorkTab : 
                      appMode === 'reverse-fmea' ? setActiveReverseFMEATab :
                      appMode === 'ai-auditor' ? setActiveAIAuditorTab :
                      setActiveCalculationsTab;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Header 
        appMode={appMode} 
        onModeChange={setAppMode} 
        username={currentUser}
        onLogout={handleLogout}
      />
      
      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        <nav className="flex space-x-1 bg-white rounded-lg p-1 shadow-sm border border-gray-200">
          {currentTabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                  activeTab === tab.id
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-gray-600 hover:text-blue-600 hover:bg-blue-50'
                }`}
              >
                <Icon className="w-4 h-4 mr-2" />
                {tab.label}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <TeamCollaboration />
        {appMode === '8d' ? render8DContent() : 
         appMode === 'work' ? renderWorkContent() : 
         appMode === 'reverse-fmea' ? renderReverseFMEAContent() :
         appMode === 'ai-auditor' ? renderAIAuditorContent() :
         renderCalculationsContent()}
      </main>
    </div>
  );
}

export default App;